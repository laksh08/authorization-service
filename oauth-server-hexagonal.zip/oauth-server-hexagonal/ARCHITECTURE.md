
Production OAuth Server (Spring Boot 4.0.6)

Features:
- OAuth2 Authorization Server with JWT
- MySQL persistence
- LDAP sync and REST endpoints
- Scheduled LDAP synchronization
- OAuth Client Self-Service Portal
- Multi-Tenant Client Support
- Token Blacklisting Cache
- Ehcache token caching
- Admin APIs
- Audit trail
- Hexagonal Architecture

Modules:
oauth-api       REST controllers
oauth-core      Domain models and use cases
oauth-security  OAuth2/JWT/security config
oauth-ldap      LDAP integration
oauth-admin     Client administration
oauth-cache     Token cache and blacklist
oauth-audit     Audit logging
oauth-infra     JPA, MySQL, external adapters
