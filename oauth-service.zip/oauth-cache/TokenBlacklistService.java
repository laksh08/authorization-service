package com.oauth.cache.blacklist;

import com.oauth.cache.config.EhcacheConfig;
import com.oauth.core.domain.TokenBlacklist;
import com.oauth.infra.repository.TokenBlacklistRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.scheduling.annotation.Scheduled;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;

/**
 * Two-tier token blacklist:
 *   L1 = Ehcache (in-process, sub-millisecond)
 *   L2 = MySQL   (persistent, survives restarts)
 *
 * On startup, warm the L1 cache from L2 for recently-revoked tokens.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TokenBlacklistService {

    private final TokenBlacklistRepository blacklistRepository;
    private final CacheManager             cacheManager;

    /**
     * Checks if a JTI is blacklisted (L1 first, then L2).
     */
    public boolean isBlacklisted(String jti) {
        if (jti == null || jti.isBlank()) return false;

        // L1 check
        Cache cache = getBlacklistCache();
        if (cache != null) {
            Cache.ValueWrapper wrapper = cache.get(jti);
            if (wrapper != null) {
                return Boolean.TRUE.equals(wrapper.get());
            }
        }

        // L2 check
        boolean inDb = blacklistRepository.existsByJti(jti);
        if (inDb && cache != null) {
            cache.put(jti, Boolean.TRUE);  // promote to L1
        }
        return inDb;
    }

    /**
     * Adds a JTI to both L1 and L2 blacklists.
     */
    @Transactional
    public void blacklist(String jti, String clientId, String tenantId,
                          Instant expiresAt, String revokedBy, String reason) {
        // Persist to L2
        TokenBlacklist entry = TokenBlacklist.builder()
                .jti(jti)
                .clientId(clientId)
                .tenantId(tenantId)
                .expiresAt(expiresAt)
                .revokedBy(revokedBy)
                .revocationReason(reason)
                .build();
        blacklistRepository.save(entry);

        // Write to L1
        Cache cache = getBlacklistCache();
        if (cache != null) {
            cache.put(jti, Boolean.TRUE);
        }

        log.info("Blacklisted token JTI='{}' for client='{}' tenant='{}'", jti, clientId, tenantId);
    }

    /**
     * Removes a JTI from the blacklist (e.g., if revocation was in error).
     */
    @Transactional
    public void removeFromBlacklist(String jti) {
        blacklistRepository.findByJti(jti).ifPresent(blacklistRepository::delete);
        Cache cache = getBlacklistCache();
        if (cache != null) cache.evict(jti);
        log.info("Removed JTI='{}' from blacklist", jti);
    }

    /**
     * Purges expired tokens from MySQL to keep the table lean.
     * Runs every hour.
     */
    @Scheduled(fixedDelayString = "PT1H")
    @Transactional
    public void purgeExpiredTokens() {
        int deleted = blacklistRepository.deleteExpiredTokens(Instant.now());
        log.info("Purged {} expired tokens from blacklist", deleted);
    }

    private Cache getBlacklistCache() {
        return cacheManager.getCache(EhcacheConfig.BLACKLIST_CACHE);
    }
}