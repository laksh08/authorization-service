package com.oauth.cache.service;

import com.oauth.cache.config.EhcacheConfig;
import com.fasterxml.jackson.core.JsonProcessingException;
import com.fasterxml.jackson.databind.ObjectMapper;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.cache.Cache;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.CacheEvict;
import org.springframework.cache.annotation.Cacheable;
import org.springframework.stereotype.Service;

import java.util.Map;
import java.util.Optional;

/**
 * Caches token introspection/validation results to avoid repeated JWT parsing and DB lookups.
 * Cache key = JTI of the token.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TokenCacheService {

    private final CacheManager cacheManager;
    private final ObjectMapper objectMapper;

    /**
     * Retrieves cached token validation result by JTI.
     */
    public Optional<Map<String, Object>> getCachedTokenInfo(String jti) {
        Cache cache = getTokenCache();
        if (cache == null) return Optional.empty();

        Cache.ValueWrapper wrapper = cache.get(jti);
        if (wrapper == null) return Optional.empty();

        try {
            String json = (String) wrapper.get();
            if (json == null) return Optional.empty();
            @SuppressWarnings("unchecked")
            Map<String, Object> claims = objectMapper.readValue(json, Map.class);
            log.debug("Token cache HIT for JTI: {}", jti);
            return Optional.of(claims);
        } catch (JsonProcessingException e) {
            log.warn("Failed to deserialize cached token info for JTI: {}", jti);
            cache.evict(jti);
            return Optional.empty();
        }
    }

    /**
     * Stores token validation result in cache.
     */
    public void cacheTokenInfo(String jti, Map<String, Object> claims) {
        Cache cache = getTokenCache();
        if (cache == null) return;

        try {
            String json = objectMapper.writeValueAsString(claims);
            cache.put(jti, json);
            log.debug("Cached token info for JTI: {}", jti);
        } catch (JsonProcessingException e) {
            log.warn("Failed to serialize token claims for caching, JTI: {}", jti);
        }
    }

    /**
     * Evicts a specific token from the cache (on revocation).
     */
    public void evictToken(String jti) {
        Cache cache = getTokenCache();
        if (cache != null) {
            cache.evict(jti);
            log.debug("Evicted token from cache: JTI={}", jti);
        }
    }

    /**
     * Evicts all cached tokens for a given client (on client update/delete).
     */
    public void evictAllForClient(String clientId) {
        // Ehcache doesn't support predicate-based eviction easily;
        // clear the entire token cache and let it repopulate.
        Cache cache = getTokenCache();
        if (cache != null) {
            cache.clear();
            log.info("Cleared entire token cache due to client update: {}", clientId);
        }
    }

    private Cache getTokenCache() {
        return cacheManager.getCache(EhcacheConfig.TOKEN_CACHE);
    }
}