package com.oauth.cache.config;

import org.ehcache.config.builders.*;
import org.ehcache.config.units.EntryUnit;
import org.ehcache.config.units.MemoryUnit;
import org.ehcache.expiry.ExpiryPolicy;
import org.ehcache.jsr107.EhcacheCachingProvider;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.cache.CacheManager;
import org.springframework.cache.annotation.EnableCaching;
import org.springframework.cache.jcache.JCacheCacheManager;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;

import javax.cache.Caching;
import javax.cache.spi.CachingProvider;
import java.time.Duration;

@Configuration
@EnableCaching
public class EhcacheConfig {

    @Value("${cache.token.max-entries:10000}")
    private long tokenCacheMaxEntries;

    @Value("${cache.token.ttl-seconds:300}")
    private long tokenCacheTtlSeconds;

    @Value("${cache.blacklist.max-entries:50000}")
    private long blacklistMaxEntries;

    @Value("${cache.blacklist.ttl-seconds:86400}")
    private long blacklistTtlSeconds;

    public static final String TOKEN_CACHE      = "tokenCache";
    public static final String BLACKLIST_CACHE  = "blacklistCache";
    public static final String CLIENT_CACHE     = "clientCache";

    @Bean
    public CacheManager cacheManager() {
        CachingProvider provider = Caching.getCachingProvider(EhcacheCachingProvider.class.getName());

        org.ehcache.CacheManager ehCacheManager = CacheManagerBuilder.newCacheManagerBuilder()
            // Token validation cache - stores token introspection results
            .withCache(TOKEN_CACHE,
                CacheConfigurationBuilder.newCacheConfigurationBuilder(
                    String.class, String.class,
                    ResourcePoolsBuilder.newResourcePoolsBuilder()
                        .heap(tokenCacheMaxEntries, EntryUnit.ENTRIES)
                        .offheap(50, MemoryUnit.MB)
                )
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(
                    Duration.ofSeconds(tokenCacheTtlSeconds)))
                .build()
            )
            // Token blacklist cache - stores revoked JTIs
            .withCache(BLACKLIST_CACHE,
                CacheConfigurationBuilder.newCacheConfigurationBuilder(
                    String.class, Boolean.class,
                    ResourcePoolsBuilder.newResourcePoolsBuilder()
                        .heap(blacklistMaxEntries, EntryUnit.ENTRIES)
                        .offheap(100, MemoryUnit.MB)
                )
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(
                    Duration.ofSeconds(blacklistTtlSeconds)))
                .build()
            )
            // Client details cache
            .withCache(CLIENT_CACHE,
                CacheConfigurationBuilder.newCacheConfigurationBuilder(
                    String.class, Object.class,
                    ResourcePoolsBuilder.newResourcePoolsBuilder()
                        .heap(5000, EntryUnit.ENTRIES)
                )
                .withExpiry(ExpiryPolicyBuilder.timeToLiveExpiration(Duration.ofMinutes(10)))
                .build()
            )
            .build(true);

        javax.cache.CacheManager jcacheManager = provider.getCacheManager(
            ehCacheManager.getClass().getResource("/ehcache.xml") != null
                ? null : null,
            getClass().getClassLoader()
        );

        // Build JCache wrapper from Ehcache manager directly
        return buildSpringCacheManager(ehCacheManager);
    }

    private CacheManager buildSpringCacheManager(org.ehcache.CacheManager ehCacheManager) {
        // Wrap Ehcache manager in Spring's JCacheCacheManager
        EhcacheCachingProvider provider = (EhcacheCachingProvider) Caching
            .getCachingProvider(EhcacheCachingProvider.class.getName());

        try {
            javax.cache.CacheManager jcm = provider.getCacheManager(
                provider.getDefaultURI(),
                provider.getDefaultClassLoader()
            );
            return new JCacheCacheManager(jcm);
        } catch (Exception e) {
            // Fallback: use a simple concurrent map cache manager for tests
            return new org.springframework.cache.concurrent.ConcurrentMapCacheManager(
                TOKEN_CACHE, BLACKLIST_CACHE, CLIENT_CACHE
            );
        }
    }
}