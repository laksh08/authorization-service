package com.oauth.core.domain;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "token_blacklist", indexes = {
    @Index(name = "idx_token_jti", columnList = "jti", unique = true),
    @Index(name = "idx_token_expiry", columnList = "expiresAt")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class TokenBlacklist {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, nullable = false)
    private UUID id;

    @Column(nullable = false, unique = true, length = 500)
    private String jti;

    @Column(nullable = false, length = 100)
    private String clientId;

    @Column(nullable = false, length = 100)
    private String tenantId;

    @Column(nullable = false)
    private Instant expiresAt;

    @Column(length = 50)
    private String revokedBy;

    @Column(length = 200)
    private String revocationReason;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant revokedAt;
}