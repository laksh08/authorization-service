package com.oauth.core.service;

import org.springframework.stereotype.Service;

import java.security.SecureRandom;
import java.util.ArrayList;
import java.util.Collections;
import java.util.List;

/**
 * Generates cryptographically secure random passwords and client secrets.
 */
@Service
public class PasswordGeneratorService {

    private static final SecureRandom SECURE_RANDOM = new SecureRandom();

    private static final String UPPERCASE   = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
    private static final String LOWERCASE   = "abcdefghijklmnopqrstuvwxyz";
    private static final String DIGITS      = "0123456789";
    private static final String SPECIAL     = "!@#$%^&*()-_=+[]{}|;:,.<>?";
    private static final String ALL_CHARS   = UPPERCASE + LOWERCASE + DIGITS + SPECIAL;
    private static final String HEX_CHARS   = "0123456789abcdef";

    /**
     * Generates a strong password with guaranteed character class coverage.
     * Default length: 24 characters.
     */
    public String generatePassword() {
        return generatePassword(24);
    }

    /**
     * Generates a strong password of the given length.
     */
    public String generatePassword(int length) {
        if (length < 12) throw new IllegalArgumentException("Password length must be at least 12");

        List<Character> chars = new ArrayList<>();

        // Guarantee at least one from each class
        chars.add(pickRandom(UPPERCASE));
        chars.add(pickRandom(LOWERCASE));
        chars.add(pickRandom(DIGITS));
        chars.add(pickRandom(SPECIAL));

        // Fill remaining
        for (int i = 4; i < length; i++) {
            chars.add(ALL_CHARS.charAt(SECURE_RANDOM.nextInt(ALL_CHARS.length())));
        }

        Collections.shuffle(chars, SECURE_RANDOM);

        StringBuilder sb = new StringBuilder(length);
        chars.forEach(sb::append);
        return sb.toString();
    }

    /**
     * Generates a URL-safe client secret (hex string, 64 chars).
     */
    public String generateClientSecret() {
        return generateHex(32); // 32 bytes = 64 hex chars
    }

    /**
     * Generates a random client ID in the format: prefix-randomhex
     */
    public String generateClientId(String prefix) {
        String safePrefix = (prefix != null && !prefix.isBlank())
                ? prefix.toLowerCase().replaceAll("[^a-z0-9]", "") : "client";
        return safePrefix + "-" + generateHex(8);
    }

    /**
     * Generates a random hex string of given byte length.
     */
    public String generateHex(int byteLength) {
        StringBuilder sb = new StringBuilder(byteLength * 2);
        for (int i = 0; i < byteLength * 2; i++) {
            sb.append(HEX_CHARS.charAt(SECURE_RANDOM.nextInt(HEX_CHARS.length())));
        }
        return sb.toString();
    }

    private char pickRandom(String chars) {
        return chars.charAt(SECURE_RANDOM.nextInt(chars.length()));
    }
}