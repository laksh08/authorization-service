package com.oauth.core.tenant;

import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.extern.slf4j.Slf4j;
import org.springframework.core.annotation.Order;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Resolves tenant from:
 * 1. X-Tenant-ID request header
 * 2. Sub-domain parsing
 * 3. Falls back to "default"
 */
@Slf4j
@Component
@Order(1)
public class TenantResolverFilter extends OncePerRequestFilter {

    public static final String TENANT_HEADER = "X-Tenant-ID";

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {
        try {
            String tenantId = resolveTenant(request);
            TenantContext.setCurrentTenant(tenantId);
            log.debug("Resolved tenant '{}' for request: {}", tenantId, request.getRequestURI());
            filterChain.doFilter(request, response);
        } finally {
            TenantContext.clear();
        }
    }

    private String resolveTenant(HttpServletRequest request) {
        // 1. Try header
        String header = request.getHeader(TENANT_HEADER);
        if (header != null && !header.isBlank()) {
            return header.trim().toLowerCase();
        }

        // 2. Try subdomain: tenant.example.com
        String host = request.getServerName();
        if (host != null) {
            String[] parts = host.split("\\.");
            if (parts.length > 2) {
                return parts[0].toLowerCase();
            }
        }

        // 3. Fall back to default
        return "default";
    }
}