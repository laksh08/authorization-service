package com.oauth.core.tenant;

import lombok.extern.slf4j.Slf4j;

/**
 * Thread-local holder for the current tenant context.
 * Must be cleared after each request to prevent memory leaks.
 */
@Slf4j
public final class TenantContext {

    private static final ThreadLocal<String> CURRENT_TENANT = new InheritableThreadLocal<>();
    private static final String DEFAULT_TENANT = "default";

    private TenantContext() {}

    public static void setCurrentTenant(String tenantId) {
        log.debug("Setting tenant context: {}", tenantId);
        CURRENT_TENANT.set(tenantId);
    }

    public static String getCurrentTenant() {
        String tenant = CURRENT_TENANT.get();
        return (tenant != null && !tenant.isBlank()) ? tenant : DEFAULT_TENANT;
    }

    public static boolean hasTenant() {
        String tenant = CURRENT_TENANT.get();
        return tenant != null && !tenant.isBlank();
    }

    public static void clear() {
        log.debug("Clearing tenant context");
        CURRENT_TENANT.remove();
    }
}