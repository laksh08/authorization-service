package com.oauth.core.domain;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.UUID;

@Entity
@Table(name = "tenants", indexes = {
    @Index(name = "idx_tenant_code", columnList = "tenantCode", unique = true)
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class Tenant {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, nullable = false)
    private UUID id;

    @Column(nullable = false, unique = true, length = 100)
    private String tenantCode;

    @Column(nullable = false, length = 200)
    private String tenantName;

    @Column(length = 500)
    private String description;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private TenantStatus status = TenantStatus.ACTIVE;

    @Column(length = 500)
    private String issuerUrl;

    @Column(nullable = false)
    @Builder.Default
    private long defaultAccessTokenValidity = 3600L;

    @Column(nullable = false)
    @Builder.Default
    private long defaultRefreshTokenValidity = 86400L;

    @Column
    private String contactEmail;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @LastModifiedDate
    @Column(nullable = false)
    private Instant updatedAt;

    public enum TenantStatus {
        ACTIVE, SUSPENDED, DELETED
    }
}