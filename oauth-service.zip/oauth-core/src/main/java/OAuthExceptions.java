package com.oauth.core.exception;

import org.springframework.http.HttpStatus;
import org.springframework.web.bind.annotation.ResponseStatus;

public final class OAuthExceptions {

    private OAuthExceptions() {}

    @ResponseStatus(HttpStatus.NOT_FOUND)
    public static class ClientNotFoundException extends RuntimeException {
        public ClientNotFoundException(String clientId) {
            super("OAuth client not found: " + clientId);
        }
    }

    @ResponseStatus(HttpStatus.CONFLICT)
    public static class ClientAlreadyExistsException extends RuntimeException {
        public ClientAlreadyExistsException(String clientId) {
            super("OAuth client already exists: " + clientId);
        }
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public static class InvalidTokenException extends RuntimeException {
        public InvalidTokenException(String message) {
            super(message);
        }
    }

    @ResponseStatus(HttpStatus.UNAUTHORIZED)
    public static class TokenRevokedException extends RuntimeException {
        public TokenRevokedException(String jti) {
            super("Token has been revoked: " + jti);
        }
    }

    @ResponseStatus(HttpStatus.NOT_FOUND)
    public static class TenantNotFoundException extends RuntimeException {
        public TenantNotFoundException(String tenantId) {
            super("Tenant not found: " + tenantId);
        }
    }

    @ResponseStatus(HttpStatus.FORBIDDEN)
    public static class TenantMismatchException extends RuntimeException {
        public TenantMismatchException(String clientId, String tenantId) {
            super("Client " + clientId + " does not belong to tenant " + tenantId);
        }
    }

    @ResponseStatus(HttpStatus.BAD_REQUEST)
    public static class InvalidClientStateException extends RuntimeException {
        public InvalidClientStateException(String message) {
            super(message);
        }
    }

    @ResponseStatus(HttpStatus.SERVICE_UNAVAILABLE)
    public static class LdapSyncException extends RuntimeException {
        public LdapSyncException(String message, Throwable cause) {
            super(message, cause);
        }
    }
}