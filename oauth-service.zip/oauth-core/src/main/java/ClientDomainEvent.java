package com.oauth.core.event;

import com.oauth.core.domain.OAuthClient;
import lombok.Getter;
import org.springframework.context.ApplicationEvent;

import java.time.Instant;

@Getter
public class ClientDomainEvent extends ApplicationEvent {

    private final EventType eventType;
    private final String clientId;
    private final String tenantId;
    private final Instant occurredAt;

    public ClientDomainEvent(Object source, EventType eventType, OAuthClient client) {
        super(source);
        this.eventType = eventType;
        this.clientId = client.getClientId();
        this.tenantId = client.getTenantId();
        this.occurredAt = Instant.now();
    }

    public ClientDomainEvent(Object source, EventType eventType, String clientId, String tenantId) {
        super(source);
        this.eventType = eventType;
        this.clientId = clientId;
        this.tenantId = tenantId;
        this.occurredAt = Instant.now();
    }

    public enum EventType {
        CLIENT_CREATED,
        CLIENT_UPDATED,
        CLIENT_DELETED,
        CLIENT_SECRET_RESET,
        CLIENT_STATUS_CHANGED,
        TOKEN_TYPE_CHANGED,
        LDAP_SYNCED
    }
}