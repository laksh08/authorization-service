package com.oauth.core.domain;

import jakarta.persistence.*;
import lombok.*;
import org.springframework.data.annotation.CreatedDate;
import org.springframework.data.annotation.LastModifiedDate;
import org.springframework.data.jpa.domain.support.AuditingEntityListener;

import java.time.Instant;
import java.util.HashSet;
import java.util.Set;
import java.util.UUID;

@Entity
@Table(name = "oauth_clients", indexes = {
    @Index(name = "idx_client_id", columnList = "clientId"),
    @Index(name = "idx_tenant_id", columnList = "tenantId")
})
@EntityListeners(AuditingEntityListener.class)
@Getter
@Setter
@Builder
@NoArgsConstructor
@AllArgsConstructor
public class OAuthClient {

    @Id
    @GeneratedValue(strategy = GenerationType.UUID)
    @Column(updatable = false, nullable = false)
    private UUID id;

    @Column(nullable = false, unique = true, length = 100)
    private String clientId;

    @Column(nullable = false, length = 500)
    private String clientSecret;

    @Column(nullable = false, length = 200)
    private String clientName;

    @Column(nullable = false, length = 100)
    private String tenantId;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private ClientStatus status = ClientStatus.ACTIVE;

    @Enumerated(EnumType.STRING)
    @Column(nullable = false)
    @Builder.Default
    private TokenType tokenType = TokenType.BEARER;

    @Column(nullable = false)
    @Builder.Default
    private boolean refreshable = false;

    @Column(nullable = false)
    @Builder.Default
    private long accessTokenValidity = 3600L;   // seconds

    @Column(nullable = false)
    @Builder.Default
    private long refreshTokenValidity = 86400L;  // seconds

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "oauth_client_scopes", joinColumns = @JoinColumn(name = "client_id"))
    @Column(name = "scope")
    @Builder.Default
    private Set<String> scopes = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "oauth_client_grant_types", joinColumns = @JoinColumn(name = "client_id"))
    @Column(name = "grant_type")
    @Builder.Default
    private Set<String> authorizedGrantTypes = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "oauth_client_redirect_uris", joinColumns = @JoinColumn(name = "client_id"))
    @Column(name = "redirect_uri")
    @Builder.Default
    private Set<String> redirectUris = new HashSet<>();

    @ElementCollection(fetch = FetchType.EAGER)
    @CollectionTable(name = "oauth_client_post_logout_uris", joinColumns = @JoinColumn(name = "client_id"))
    @Column(name = "post_logout_uri")
    @Builder.Default
    private Set<String> postLogoutRedirectUris = new HashSet<>();

    @Column(length = 1000)
    private String description;

    @Column(nullable = false)
    @Builder.Default
    private boolean ldapSynced = false;

    @Column
    private String ldapDn;

    @Column
    private Instant ldapLastSyncAt;

    @CreatedDate
    @Column(nullable = false, updatable = false)
    private Instant createdAt;

    @LastModifiedDate
    @Column(nullable = false)
    private Instant updatedAt;

    @Column
    private Instant deletedAt;

    public boolean isActive() {
        return ClientStatus.ACTIVE.equals(this.status) && this.deletedAt == null;
    }

    public void softDelete() {
        this.status = ClientStatus.DELETED;
        this.deletedAt = Instant.now();
    }

    public enum ClientStatus {
        ACTIVE, INACTIVE, DELETED, SUSPENDED
    }

    public enum TokenType {
        BEARER, MAC
    }
}