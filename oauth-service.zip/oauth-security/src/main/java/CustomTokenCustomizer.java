package com.oauth.security.jwt;

import com.oauth.core.domain.OAuthClient;
import com.oauth.infra.repository.OAuthClientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.server.authorization.token.JwtEncodingContext;
import org.springframework.security.oauth2.server.authorization.token.OAuth2TokenCustomizer;
import org.springframework.stereotype.Component;

import java.util.Optional;

/**
 * Enriches JWT tokens with additional claims:
 * - tenant_id: the owning tenant
 * - client_name: human-readable client name
 * - token_version: for future revocation support
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class CustomTokenCustomizer implements OAuth2TokenCustomizer<JwtEncodingContext> {

    private final OAuthClientRepository clientRepository;

    @Override
    public void customize(JwtEncodingContext context) {
        String clientId = context.getRegisteredClient().getClientId();

        Optional<OAuthClient> clientOpt = clientRepository.findByClientId(clientId);
        clientOpt.ifPresentOrElse(client -> {
            context.getClaims()
                   .claim("tenant_id",   client.getTenantId())
                   .claim("client_name", client.getClientName())
                   .claim("token_type",  client.getTokenType().name())
                   .claim("token_version", "1");

            log.debug("Customized JWT for client '{}' in tenant '{}'", clientId, client.getTenantId());
        }, () -> {
            log.warn("Client '{}' not found in oauth_clients during token customization", clientId);
        });
    }
}