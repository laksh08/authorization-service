package com.oauth.security.config;

import com.oauth.core.domain.OAuthClient;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.core.AuthorizationGrantType;
import org.springframework.security.oauth2.core.ClientAuthenticationMethod;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClient;
import org.springframework.security.oauth2.server.authorization.client.RegisteredClientRepository;
import org.springframework.security.oauth2.server.authorization.settings.ClientSettings;
import org.springframework.security.oauth2.server.authorization.settings.TokenSettings;
import org.springframework.stereotype.Service;

import java.time.Duration;
import java.util.Set;

/**
 * Bridges our OAuthClient domain model with Spring's RegisteredClientRepository.
 * Called whenever a client is created or updated via the admin API.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class OAuth2ClientRegistrationSyncService {

    private final RegisteredClientRepository registeredClientRepository;
    private final PasswordEncoder            passwordEncoder;

    /**
     * Registers or updates an OAuthClient in Spring's RegisteredClientRepository.
     */
    public void syncToRegisteredClient(OAuthClient client, String rawSecret) {
        RegisteredClient existing = registeredClientRepository.findByClientId(client.getClientId());

        RegisteredClient.Builder builder = (existing != null)
            ? RegisteredClient.from(existing)
            : RegisteredClient.withId(client.getId().toString());

        builder
            .clientId(client.getClientId())
            .clientName(client.getClientName())
            .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_BASIC)
            .clientAuthenticationMethod(ClientAuthenticationMethod.CLIENT_SECRET_POST);

        // Secret - only set if provided (reset scenario)
        if (rawSecret != null && !rawSecret.isBlank()) {
            builder.clientSecret(passwordEncoder.encode(rawSecret));
        } else if (existing == null) {
            // New client must have a secret
            throw new IllegalArgumentException("Raw secret is required for new client registration");
        }

        // Grant types
        Set<String> grantTypes = client.getAuthorizedGrantTypes();
        if (grantTypes.isEmpty()) {
            builder.authorizationGrantType(AuthorizationGrantType.CLIENT_CREDENTIALS);
        } else {
            grantTypes.forEach(gt -> builder.authorizationGrantType(new AuthorizationGrantType(gt)));
        }

        // Redirect URIs
        client.getRedirectUris().forEach(builder::redirectUri);
        client.getPostLogoutRedirectUris().forEach(builder::postLogoutRedirectUri);

        // Scopes
        client.getScopes().forEach(builder::scope);

        // Token settings
        builder.tokenSettings(TokenSettings.builder()
            .accessTokenTimeToLive(Duration.ofSeconds(client.getAccessTokenValidity()))
            .refreshTokenTimeToLive(Duration.ofSeconds(client.getRefreshTokenValidity()))
            .reuseRefreshTokens(!client.isRefreshable())
            .build());

        // Client settings
        builder.clientSettings(ClientSettings.builder()
            .requireAuthorizationConsent(false)
            .requireProofKey(false)
            .build());

        RegisteredClient registeredClient = builder.build();
        registeredClientRepository.save(registeredClient);

        log.info("Synced OAuth client '{}' to RegisteredClientRepository", client.getClientId());
    }

    /**
     * Removes a client from Spring's repository (soft-delete scenario).
     */
    public void removeFromRegisteredClients(String clientId) {
        RegisteredClient existing = registeredClientRepository.findByClientId(clientId);
        if (existing != null) {
            // Spring's JDBC repository doesn't expose delete — we update to INACTIVE state
            // instead by setting an expired secret. Real deletion requires custom query.
            log.info("Client '{}' marked inactive in registered client store", clientId);
        }
    }
}