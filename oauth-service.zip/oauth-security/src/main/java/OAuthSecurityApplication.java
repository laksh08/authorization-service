package com.oauth.security;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.context.annotation.ComponentScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;
import org.springframework.scheduling.annotation.EnableScheduling;

@SpringBootApplication
@ComponentScan(basePackages = {
    "com.oauth.security",
    "com.oauth.core",
    "com.oauth.infra",
    "com.oauth.cache",
    "com.oauth.admin",
    "com.oauth.ldap",
    "com.oauth.api",
    "com.oauth.audit"
})
@EntityScan(basePackages = "com.oauth.core.domain")
@EnableJpaRepositories(basePackages = "com.oauth.infra.repository")
@EnableScheduling
public class OAuthSecurityApplication {

    public static void main(String[] args) {
        SpringApplication.run(OAuthSecurityApplication.class, args);
    }
}