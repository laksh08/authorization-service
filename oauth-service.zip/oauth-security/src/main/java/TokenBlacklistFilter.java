package com.oauth.security.filter;

import com.oauth.cache.blacklist.TokenBlacklistService;
import com.oauth.security.jwt.JwtTokenService;
import jakarta.servlet.FilterChain;
import jakarta.servlet.ServletException;
import jakarta.servlet.http.HttpServletRequest;
import jakarta.servlet.http.HttpServletResponse;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.HttpStatus;
import org.springframework.stereotype.Component;
import org.springframework.web.filter.OncePerRequestFilter;

import java.io.IOException;

/**
 * Intercepts incoming requests and checks the Bearer token against the blacklist.
 * Rejects blacklisted tokens with 401 before they reach the resource server.
 */
@Slf4j
@Component
@RequiredArgsConstructor
public class TokenBlacklistFilter extends OncePerRequestFilter {

    private final TokenBlacklistService blacklistService;
    private final JwtTokenService       jwtTokenService;

    @Override
    protected void doFilterInternal(HttpServletRequest request,
                                    HttpServletResponse response,
                                    FilterChain filterChain) throws ServletException, IOException {

        String authHeader = request.getHeader(HttpHeaders.AUTHORIZATION);

        if (authHeader != null && authHeader.startsWith("Bearer ")) {
            String token = authHeader.substring(7);
            String jti   = jwtTokenService.extractJti(token);

            if (jti != null && blacklistService.isBlacklisted(jti)) {
                log.warn("Rejected blacklisted token with JTI: {}", jti);
                response.setStatus(HttpStatus.UNAUTHORIZED.value());
                response.setContentType("application/json");
                response.getWriter().write(
                    "{\"error\":\"token_revoked\",\"error_description\":\"Token has been revoked\"}"
                );
                return;
            }
        }

        filterChain.doFilter(request, response);
    }

    @Override
    protected boolean shouldNotFilter(HttpServletRequest request) {
        String path = request.getRequestURI();
        // Skip blacklist check for token issuance and public endpoints
        return path.startsWith("/oauth2/token")
            || path.startsWith("/oauth2/jwks")
            || path.startsWith("/actuator/health")
            || path.startsWith("/.well-known");
    }
}