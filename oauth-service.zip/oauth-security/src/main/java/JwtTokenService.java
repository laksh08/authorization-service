package com.oauth.security.jwt;

import com.oauth.core.exception.OAuthExceptions;
import com.oauth.security.keys.JwkKeyManager;
import io.jsonwebtoken.*;
import io.jsonwebtoken.security.Keys;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.Date;
import java.util.Map;
import java.util.UUID;

/**
 * Low-level JWT operations: build, sign, parse, and validate tokens.
 * Uses RSA RS256 for signing.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class JwtTokenService {

    private final JwkKeyManager keyManager;

    @Value("${oauth.issuer-uri:http://localhost:9000}")
    private String issuerUri;

    /**
     * Parses and validates a raw JWT string.
     * Throws InvalidTokenException on any failure.
     */
    public Claims parseAndValidate(String token) {
        try {
            return Jwts.parser()
                    .verifyWith(keyManager.getPublicKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
        } catch (ExpiredJwtException e) {
            log.debug("JWT expired: {}", e.getMessage());
            throw new OAuthExceptions.InvalidTokenException("Token has expired");
        } catch (JwtException e) {
            log.debug("JWT invalid: {}", e.getMessage());
            throw new OAuthExceptions.InvalidTokenException("Token is invalid: " + e.getMessage());
        }
    }

    /**
     * Builds a signed JWT with the given claims.
     */
    public String buildToken(String subject, String clientId, String tenantId,
                             Map<String, Object> additionalClaims, long validitySeconds) {
        Instant now     = Instant.now();
        Instant expiry  = now.plusSeconds(validitySeconds);
        String  jti     = UUID.randomUUID().toString();

        JwtBuilder builder = Jwts.builder()
                .id(jti)
                .subject(subject)
                .issuer(issuerUri)
                .issuedAt(Date.from(now))
                .expiration(Date.from(expiry))
                .claim("client_id", clientId)
                .claim("tenant_id", tenantId)
                .signWith(keyManager.getPrivateKey(), Jwts.SIG.RS256);

        if (additionalClaims != null) {
            additionalClaims.forEach(builder::claim);
        }

        return builder.compact();
    }

    /**
     * Extracts the JTI (JWT ID) without full validation.
     * Useful for blacklist checks before full parse.
     */
    public String extractJti(String token) {
        try {
            Claims claims = parseAndValidate(token);
            return claims.getId();
        } catch (Exception e) {
            // Try to extract even from expired tokens
            try {
                String[] parts = token.split("\\.");
                if (parts.length >= 2) {
                    String payloadJson = new String(java.util.Base64.getUrlDecoder().decode(parts[1]));
                    // Simple extraction without full parse
                    int jtiStart = payloadJson.indexOf("\"jti\":\"") + 7;
                    int jtiEnd   = payloadJson.indexOf("\"", jtiStart);
                    if (jtiStart > 6 && jtiEnd > jtiStart) {
                        return payloadJson.substring(jtiStart, jtiEnd);
                    }
                }
            } catch (Exception ignored) {}
            return null;
        }
    }

    /**
     * Extracts token expiry without throwing on expiry.
     */
    public Instant extractExpiry(String token) {
        try {
            Claims claims = Jwts.parser()
                    .verifyWith(keyManager.getPublicKey())
                    .build()
                    .parseSignedClaims(token)
                    .getPayload();
            return claims.getExpiration().toInstant();
        } catch (ExpiredJwtException e) {
            return e.getClaims().getExpiration().toInstant();
        } catch (Exception e) {
            return Instant.now().minusSeconds(1); // treat as expired
        }
    }

    /**
     * Returns true if the token signature and structure are valid (may be expired).
     */
    public boolean isSignatureValid(String token) {
        try {
            Jwts.parser()
                .verifyWith(keyManager.getPublicKey())
                .build()
                .parseSignedClaims(token);
            return true;
        } catch (ExpiredJwtException e) {
            return true; // signature valid, just expired
        } catch (Exception e) {
            return false;
        }
    }
}