package com.oauth.infra.repository;

import com.oauth.core.domain.OAuthClient;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Modifying;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.Optional;
import java.util.UUID;

@Repository
public interface OAuthClientRepository extends JpaRepository<OAuthClient, UUID> {

    Optional<OAuthClient> findByClientId(String clientId);

    Optional<OAuthClient> findByClientIdAndTenantId(String clientId, String tenantId);

    boolean existsByClientId(String clientId);

    List<OAuthClient> findAllByTenantId(String tenantId);

    Page<OAuthClient> findAllByTenantId(String tenantId, Pageable pageable);

    @Query("SELECT c FROM OAuthClient c WHERE c.tenantId = :tenantId AND c.status = 'ACTIVE' AND c.deletedAt IS NULL")
    List<OAuthClient> findActiveClientsByTenantId(@Param("tenantId") String tenantId);

    @Query("SELECT c FROM OAuthClient c WHERE c.ldapSynced = true AND c.tenantId = :tenantId")
    List<OAuthClient> findLdapSyncedClientsByTenantId(@Param("tenantId") String tenantId);

    @Query("SELECT c FROM OAuthClient c WHERE c.ldapSynced = true")
    List<OAuthClient> findAllLdapSyncedClients();

    @Query("SELECT c FROM OAuthClient c WHERE c.ldapLastSyncAt < :threshold OR c.ldapLastSyncAt IS NULL")
    List<OAuthClient> findClientsNeedingLdapSync(@Param("threshold") Instant threshold);

    @Modifying
    @Query("UPDATE OAuthClient c SET c.status = :status, c.updatedAt = :now WHERE c.clientId = :clientId")
    int updateClientStatus(@Param("clientId") String clientId,
                           @Param("status") OAuthClient.ClientStatus status,
                           @Param("now") Instant now);

    @Query("SELECT COUNT(c) FROM OAuthClient c WHERE c.tenantId = :tenantId AND c.status = 'ACTIVE'")
    long countActiveClientsByTenant(@Param("tenantId") String tenantId);

    @Query("SELECT c FROM OAuthClient c WHERE c.clientName LIKE %:name% AND c.tenantId = :tenantId")
    Page<OAuthClient> searchByNameAndTenantId(@Param("name") String name,
                                              @Param("tenantId") String tenantId,
                                              Pageable pageable);
}