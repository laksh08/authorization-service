package com.oauth.infra.repository;

import com.oauth.core.domain.AuditLog;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.data.repository.query.Param;
import org.springframework.stereotype.Repository;

import java.time.Instant;
import java.util.List;
import java.util.UUID;

@Repository
public interface AuditLogRepository extends JpaRepository<AuditLog, UUID> {

    Page<AuditLog> findByClientIdOrderByCreatedAtDesc(String clientId, Pageable pageable);

    Page<AuditLog> findByTenantIdOrderByCreatedAtDesc(String tenantId, Pageable pageable);

    @Query("SELECT a FROM AuditLog a WHERE a.createdAt BETWEEN :from AND :to ORDER BY a.createdAt DESC")
    List<AuditLog> findByDateRange(@Param("from") Instant from, @Param("to") Instant to);

    @Query("SELECT a FROM AuditLog a WHERE a.tenantId = :tenantId AND a.status = 'FAILURE' ORDER BY a.createdAt DESC")
    List<AuditLog> findFailuresByTenant(@Param("tenantId") String tenantId, Pageable pageable);
}