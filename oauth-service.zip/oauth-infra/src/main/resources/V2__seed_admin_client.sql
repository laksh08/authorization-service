-- ============================================================
-- V2__seed_admin_client.sql
-- Creates an initial admin OAuth client for bootstrapping
-- ============================================================

-- Insert a default admin client (secret: admin-secret-change-me)
-- BCrypt hash of 'admin-secret-change-me'
INSERT INTO oauth_clients (
    id,
    client_id,
    client_secret,
    client_name,
    tenant_id,
    status,
    token_type,
    refreshable,
    access_token_validity,
    refresh_token_validity,
    description
) VALUES (
    UUID(),
    'admin-client',
    '$2a$12$8LIjOaFJlH9XFCnkq3KbxOMp3.HzqC6bTUdGvB4Q5sOp6sW9qfHmm',
    'Admin Client',
    'default',
    'ACTIVE',
    'BEARER',
    1,
    3600,
    86400,
    'Bootstrap admin client - change secret immediately in production'
);

-- Scopes for admin client
INSERT INTO oauth_client_scopes (client_id, scope)
SELECT id, scope FROM oauth_clients
CROSS JOIN (SELECT 'read' AS scope UNION SELECT 'write' UNION SELECT 'admin' UNION SELECT 'openid') s
WHERE oauth_clients.client_id = 'admin-client';

-- Grant types for admin client
INSERT INTO oauth_client_grant_types (client_id, grant_type)
SELECT id, grant_type FROM oauth_clients
CROSS JOIN (SELECT 'client_credentials' AS grant_type UNION SELECT 'refresh_token') g
WHERE oauth_clients.client_id = 'admin-client';