-- ============================================================
-- V1__initial_schema.sql
-- Creates core tables for the OAuth Authorization Service
-- ============================================================

-- Tenants table
CREATE TABLE IF NOT EXISTS tenants (
    id                          CHAR(36)        NOT NULL,
    tenant_code                 VARCHAR(100)    NOT NULL,
    tenant_name                 VARCHAR(200)    NOT NULL,
    description                 VARCHAR(500)    NULL,
    status                      VARCHAR(30)     NOT NULL DEFAULT 'ACTIVE',
    issuer_url                  VARCHAR(500)    NULL,
    default_access_token_validity   BIGINT      NOT NULL DEFAULT 3600,
    default_refresh_token_validity  BIGINT      NOT NULL DEFAULT 86400,
    contact_email               VARCHAR(200)    NULL,
    created_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE INDEX idx_tenant_code (tenant_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Insert default tenant
INSERT INTO tenants (id, tenant_code, tenant_name, description, status, issuer_url, default_access_token_validity, default_refresh_token_validity)
VALUES (UUID(), 'default', 'Default Tenant', 'System default tenant', 'ACTIVE', 'http://localhost:9000', 3600, 86400);

-- OAuth Clients table
CREATE TABLE IF NOT EXISTS oauth_clients (
    id                          CHAR(36)        NOT NULL,
    client_id                   VARCHAR(100)    NOT NULL,
    client_secret               VARCHAR(500)    NOT NULL,
    client_name                 VARCHAR(200)    NOT NULL,
    tenant_id                   VARCHAR(100)    NOT NULL DEFAULT 'default',
    status                      VARCHAR(30)     NOT NULL DEFAULT 'ACTIVE',
    token_type                  VARCHAR(20)     NOT NULL DEFAULT 'BEARER',
    refreshable                 TINYINT(1)      NOT NULL DEFAULT 0,
    access_token_validity       BIGINT          NOT NULL DEFAULT 3600,
    refresh_token_validity      BIGINT          NOT NULL DEFAULT 86400,
    description                 VARCHAR(1000)   NULL,
    ldap_synced                 TINYINT(1)      NOT NULL DEFAULT 0,
    ldap_dn                     VARCHAR(500)    NULL,
    ldap_last_sync_at           DATETIME(6)     NULL,
    created_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    updated_at                  DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6) ON UPDATE CURRENT_TIMESTAMP(6),
    deleted_at                  DATETIME(6)     NULL,
    PRIMARY KEY (id),
    UNIQUE INDEX idx_client_id (client_id),
    INDEX idx_tenant_id (tenant_id),
    INDEX idx_status (status),
    CONSTRAINT fk_client_tenant FOREIGN KEY (tenant_id) REFERENCES tenants(tenant_code)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Client Scopes
CREATE TABLE IF NOT EXISTS oauth_client_scopes (
    client_id   CHAR(36)        NOT NULL,
    scope       VARCHAR(100)    NOT NULL,
    PRIMARY KEY (client_id, scope),
    CONSTRAINT fk_scope_client FOREIGN KEY (client_id) REFERENCES oauth_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Client Grant Types
CREATE TABLE IF NOT EXISTS oauth_client_grant_types (
    client_id   CHAR(36)        NOT NULL,
    grant_type  VARCHAR(100)    NOT NULL,
    PRIMARY KEY (client_id, grant_type),
    CONSTRAINT fk_grant_client FOREIGN KEY (client_id) REFERENCES oauth_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Client Redirect URIs
CREATE TABLE IF NOT EXISTS oauth_client_redirect_uris (
    client_id       CHAR(36)        NOT NULL,
    redirect_uri    VARCHAR(500)    NOT NULL,
    PRIMARY KEY (client_id, redirect_uri),
    CONSTRAINT fk_redirect_client FOREIGN KEY (client_id) REFERENCES oauth_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Client Post Logout Redirect URIs
CREATE TABLE IF NOT EXISTS oauth_client_post_logout_uris (
    client_id           CHAR(36)        NOT NULL,
    post_logout_uri     VARCHAR(500)    NOT NULL,
    PRIMARY KEY (client_id, post_logout_uri),
    CONSTRAINT fk_post_logout_client FOREIGN KEY (client_id) REFERENCES oauth_clients(id) ON DELETE CASCADE
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Token Blacklist
CREATE TABLE IF NOT EXISTS token_blacklist (
    id                  CHAR(36)        NOT NULL,
    jti                 VARCHAR(500)    NOT NULL,
    client_id           VARCHAR(100)    NOT NULL,
    tenant_id           VARCHAR(100)    NOT NULL,
    expires_at          DATETIME(6)     NOT NULL,
    revoked_by          VARCHAR(50)     NULL,
    revocation_reason   VARCHAR(200)    NULL,
    revoked_at          DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    UNIQUE INDEX idx_token_jti (jti),
    INDEX idx_token_expiry (expires_at),
    INDEX idx_token_client (client_id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Audit Logs
CREATE TABLE IF NOT EXISTS audit_logs (
    id              CHAR(36)        NOT NULL,
    action          VARCHAR(100)    NOT NULL,
    client_id       VARCHAR(100)    NULL,
    tenant_id       VARCHAR(100)    NULL,
    performed_by    VARCHAR(100)    NULL,
    ip_address      VARCHAR(50)     NULL,
    request_payload TEXT            NULL,
    response_payload TEXT           NULL,
    status          VARCHAR(20)     NOT NULL DEFAULT 'SUCCESS',
    error_message   VARCHAR(500)    NULL,
    created_at      DATETIME(6)     NOT NULL DEFAULT CURRENT_TIMESTAMP(6),
    PRIMARY KEY (id),
    INDEX idx_audit_client (client_id),
    INDEX idx_audit_tenant (tenant_id),
    INDEX idx_audit_created (created_at)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_unicode_ci;

-- Spring Authorization Server tables (required by spring-security-oauth2-authorization-server)
CREATE TABLE IF NOT EXISTS oauth2_registered_client (
    id                            VARCHAR(100)                NOT NULL,
    client_id                     VARCHAR(100)                NOT NULL,
    client_id_issued_at           TIMESTAMP   DEFAULT CURRENT_TIMESTAMP NOT NULL,
    client_secret                 VARCHAR(200)                DEFAULT NULL,
    client_secret_expires_at      TIMESTAMP                   DEFAULT NULL,
    client_name                   VARCHAR(200)                NOT NULL,
    client_authentication_methods VARCHAR(1000)               NOT NULL,
    authorization_grant_types     VARCHAR(1000)               NOT NULL,
    redirect_uris                 VARCHAR(1000)               DEFAULT NULL,
    post_logout_redirect_uris     VARCHAR(1000)               DEFAULT NULL,
    scopes                        VARCHAR(1000)               NOT NULL,
    client_settings               VARCHAR(2000)               NOT NULL,
    token_settings                VARCHAR(2000)               NOT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS oauth2_authorization (
    id                            VARCHAR(100) NOT NULL,
    registered_client_id          VARCHAR(100) NOT NULL,
    principal_name                VARCHAR(200) NOT NULL,
    authorization_grant_type      VARCHAR(100) NOT NULL,
    authorized_scopes             VARCHAR(1000) DEFAULT NULL,
    attributes                    BLOB         DEFAULT NULL,
    state                         VARCHAR(500) DEFAULT NULL,
    authorization_code_value      BLOB         DEFAULT NULL,
    authorization_code_issued_at  TIMESTAMP    DEFAULT NULL,
    authorization_code_expires_at TIMESTAMP    DEFAULT NULL,
    authorization_code_metadata   BLOB         DEFAULT NULL,
    access_token_value            BLOB         DEFAULT NULL,
    access_token_issued_at        TIMESTAMP    DEFAULT NULL,
    access_token_expires_at       TIMESTAMP    DEFAULT NULL,
    access_token_metadata         BLOB         DEFAULT NULL,
    access_token_type             VARCHAR(100) DEFAULT NULL,
    access_token_scopes           VARCHAR(1000) DEFAULT NULL,
    oidc_id_token_value           BLOB         DEFAULT NULL,
    oidc_id_token_issued_at       TIMESTAMP    DEFAULT NULL,
    oidc_id_token_expires_at      TIMESTAMP    DEFAULT NULL,
    oidc_id_token_metadata        BLOB         DEFAULT NULL,
    refresh_token_value           BLOB         DEFAULT NULL,
    refresh_token_issued_at       TIMESTAMP    DEFAULT NULL,
    refresh_token_expires_at      TIMESTAMP    DEFAULT NULL,
    refresh_token_metadata        BLOB         DEFAULT NULL,
    user_code_value               BLOB         DEFAULT NULL,
    user_code_issued_at           TIMESTAMP    DEFAULT NULL,
    user_code_expires_at          TIMESTAMP    DEFAULT NULL,
    user_code_metadata            BLOB         DEFAULT NULL,
    device_code_value             BLOB         DEFAULT NULL,
    device_code_issued_at         TIMESTAMP    DEFAULT NULL,
    device_code_expires_at        TIMESTAMP    DEFAULT NULL,
    device_code_metadata          BLOB         DEFAULT NULL,
    PRIMARY KEY (id)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

CREATE TABLE IF NOT EXISTS oauth2_authorization_consent (
    registered_client_id  VARCHAR(100)  NOT NULL,
    principal_name        VARCHAR(200)  NOT NULL,
    authorities           VARCHAR(1000) NOT NULL,
    PRIMARY KEY (registered_client_id, principal_name)
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;