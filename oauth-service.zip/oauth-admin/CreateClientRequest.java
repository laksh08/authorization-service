package com.oauth.admin.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.Set;

@Data
public class CreateClientRequest {

    @NotBlank(message = "clientName is required")
    @Size(min = 3, max = 200)
    private String clientName;

    @Size(max = 100)
    private String clientId;  // If blank, will be auto-generated

    @Size(max = 100)
    private String tenantId;  // Defaults to resolved tenant

    @Size(max = 1000)
    private String description;

    @NotEmpty(message = "At least one scope is required")
    private Set<String> scopes;

    @NotEmpty(message = "At least one grant type is required")
    private Set<String> authorizedGrantTypes;

    private Set<String> redirectUris;

    private Set<String> postLogoutRedirectUris;

    @Min(60)
    @Max(86400)
    private long accessTokenValidity = 3600L;

    @Min(60)
    @Max(2592000)
    private long refreshTokenValidity = 86400L;

    private boolean refreshable = false;
}