package com.oauth.admin.dto;

import com.oauth.core.domain.OAuthClient;
import jakarta.validation.constraints.*;
import lombok.Data;

import java.util.Set;

@Data
public class UpdateClientRequest {

    @Size(min = 3, max = 200)
    private String clientName;

    @Size(max = 1000)
    private String description;

    private Set<String> scopes;

    private Set<String> authorizedGrantTypes;

    private Set<String> redirectUris;

    private Set<String> postLogoutRedirectUris;

    @Min(60)
    @Max(86400)
    private Long accessTokenValidity;

    @Min(60)
    @Max(2592000)
    private Long refreshTokenValidity;

    private Boolean refreshable;

    private OAuthClient.ClientStatus status;
}