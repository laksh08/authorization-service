package com.oauth.admin.dto;

import com.oauth.core.domain.OAuthClient;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.Set;
import java.util.UUID;

@Data
@Builder
public class ClientResponse {

    private UUID    id;
    private String  clientId;
    private String  clientName;
    private String  tenantId;
    private String  description;
    private OAuthClient.ClientStatus  status;
    private OAuthClient.TokenType     tokenType;
    private boolean refreshable;
    private long    accessTokenValidity;
    private long    refreshTokenValidity;
    private Set<String> scopes;
    private Set<String> authorizedGrantTypes;
    private Set<String> redirectUris;
    private Set<String> postLogoutRedirectUris;
    private boolean ldapSynced;
    private Instant ldapLastSyncAt;
    private Instant createdAt;
    private Instant updatedAt;
}