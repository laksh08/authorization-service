package com.oauth.admin.mapper;

import com.oauth.admin.dto.ClientResponse;
import com.oauth.core.domain.OAuthClient;
import org.mapstruct.Mapper;
import org.mapstruct.MappingConstants;

import java.util.List;

@Mapper(componentModel = MappingConstants.ComponentModel.SPRING)
public interface ClientMapper {

    ClientResponse toResponse(OAuthClient client);

    List<ClientResponse> toResponseList(List<OAuthClient> clients);
}