package com.oauth.admin.service;

import com.oauth.admin.dto.*;
import com.oauth.admin.mapper.ClientMapper;
import com.oauth.cache.service.TokenCacheService;
import com.oauth.core.domain.OAuthClient;
import com.oauth.core.event.ClientDomainEvent;
import com.oauth.core.exception.OAuthExceptions;
import com.oauth.core.service.PasswordGeneratorService;
import com.oauth.core.tenant.TenantContext;
import com.oauth.infra.repository.OAuthClientRepository;
import com.oauth.infra.repository.TenantRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;
import java.util.List;
import java.util.Optional;

@Slf4j
@Service
@RequiredArgsConstructor
public class AdminClientService {

    private final OAuthClientRepository  clientRepository;
    private final TenantRepository       tenantRepository;
    private final PasswordGeneratorService passwordGenerator;
    private final PasswordEncoder        passwordEncoder;
    private final ApplicationEventPublisher eventPublisher;
    private final TokenCacheService      tokenCacheService;
    private final ClientMapper           clientMapper;

    // ─── CREATE ─────────────────────────────────────────────────────────────────

    @Transactional
    public ClientCreatedResponse createClient(CreateClientRequest request) {
        String tenantId = resolveTenant(request.getTenantId());
        validateTenantExists(tenantId);

        // Determine client ID
        String clientId = (request.getClientId() != null && !request.getClientId().isBlank())
            ? request.getClientId().trim()
            : passwordGenerator.generateClientId(sanitize(request.getClientName()));

        if (clientRepository.existsByClientId(clientId)) {
            throw new OAuthExceptions.ClientAlreadyExistsException(clientId);
        }

        // Generate secret
        String rawSecret = passwordGenerator.generateClientSecret();

        OAuthClient client = OAuthClient.builder()
            .clientId(clientId)
            .clientSecret(passwordEncoder.encode(rawSecret))
            .clientName(request.getClientName())
            .tenantId(tenantId)
            .description(request.getDescription())
            .scopes(new HashSet<>(request.getScopes()))
            .authorizedGrantTypes(new HashSet<>(request.getAuthorizedGrantTypes()))
            .redirectUris(request.getRedirectUris() != null ? new HashSet<>(request.getRedirectUris()) : new HashSet<>())
            .postLogoutRedirectUris(request.getPostLogoutRedirectUris() != null
                ? new HashSet<>(request.getPostLogoutRedirectUris()) : new HashSet<>())
            .accessTokenValidity(request.getAccessTokenValidity())
            .refreshTokenValidity(request.getRefreshTokenValidity())
            .refreshable(request.isRefreshable())
            .build();

        client = clientRepository.save(client);
        log.info("Created OAuth client '{}' in tenant '{}'", clientId, tenantId);

        eventPublisher.publishEvent(new ClientDomainEvent(this, ClientDomainEvent.EventType.CLIENT_CREATED, client));

        return ClientCreatedResponse.builder()
            .client(clientMapper.toResponse(client))
            .clientSecret(rawSecret)
            .message("Client created. Store the secret securely — it cannot be retrieved again.")
            .build();
    }

    // ─── READ ────────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public ClientResponse getClient(String clientId) {
        OAuthClient client = requireClientInTenant(clientId);
        return clientMapper.toResponse(client);
    }

    @Transactional(readOnly = true)
    public List<ClientResponse> getAllClientsForTenant(String tenantId) {
        String resolved = resolveTenant(tenantId);
        return clientMapper.toResponseList(clientRepository.findAllByTenantId(resolved));
    }

    @Transactional(readOnly = true)
    public Page<ClientResponse> searchClients(String name, Pageable pageable) {
        String tenantId = TenantContext.getCurrentTenant();
        return clientRepository.searchByNameAndTenantId(name, tenantId, pageable)
                               .map(clientMapper::toResponse);
    }

    // ─── UPDATE ──────────────────────────────────────────────────────────────────

    @Transactional
    public ClientResponse updateClient(String clientId, UpdateClientRequest request) {
        OAuthClient client = requireClientInTenant(clientId);

        if (request.getClientName() != null)          client.setClientName(request.getClientName());
        if (request.getDescription() != null)         client.setDescription(request.getDescription());
        if (request.getScopes() != null)              client.setScopes(new HashSet<>(request.getScopes()));
        if (request.getAuthorizedGrantTypes() != null)
            client.setAuthorizedGrantTypes(new HashSet<>(request.getAuthorizedGrantTypes()));
        if (request.getRedirectUris() != null)
            client.setRedirectUris(new HashSet<>(request.getRedirectUris()));
        if (request.getPostLogoutRedirectUris() != null)
            client.setPostLogoutRedirectUris(new HashSet<>(request.getPostLogoutRedirectUris()));
        if (request.getAccessTokenValidity() != null)
            client.setAccessTokenValidity(request.getAccessTokenValidity());
        if (request.getRefreshTokenValidity() != null)
            client.setRefreshTokenValidity(request.getRefreshTokenValidity());
        if (request.getRefreshable() != null)         client.setRefreshable(request.getRefreshable());
        if (request.getStatus() != null)              client.setStatus(request.getStatus());

        client = clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);

        log.info("Updated client '{}'", clientId);
        eventPublisher.publishEvent(new ClientDomainEvent(this, ClientDomainEvent.EventType.CLIENT_UPDATED, client));

        return clientMapper.toResponse(client);
    }

    // ─── DELETE ──────────────────────────────────────────────────────────────────

    @Transactional
    public void deleteClient(String clientId) {
        OAuthClient client = requireClientInTenant(clientId);
        client.softDelete();
        clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);

        log.info("Soft-deleted client '{}'", clientId);
        eventPublisher.publishEvent(new ClientDomainEvent(this, ClientDomainEvent.EventType.CLIENT_DELETED, client));
    }

    // ─── SECRET MANAGEMENT ───────────────────────────────────────────────────────

    @Transactional
    public ClientCreatedResponse resetClientSecret(String clientId) {
        OAuthClient client = requireClientInTenant(clientId);

        String newRawSecret = passwordGenerator.generateClientSecret();
        client.setClientSecret(passwordEncoder.encode(newRawSecret));
        clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);

        log.info("Reset secret for client '{}'", clientId);
        eventPublisher.publishEvent(
            new ClientDomainEvent(this, ClientDomainEvent.EventType.CLIENT_SECRET_RESET, client));

        return ClientCreatedResponse.builder()
            .client(clientMapper.toResponse(client))
            .clientSecret(newRawSecret)
            .message("Secret reset. Store the new secret securely.")
            .build();
    }

    @Transactional
    public String resetClientPassword(String clientId, String newPassword) {
        OAuthClient client = requireClientInTenant(clientId);
        String encoded = passwordEncoder.encode(newPassword);
        client.setClientSecret(encoded);
        clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);
        log.info("Password reset for client '{}' by admin", clientId);
        return "Password updated successfully";
    }

    // ─── RANDOM PASSWORD ─────────────────────────────────────────────────────────

    public String generateRandomPassword() {
        return passwordGenerator.generatePassword();
    }

    // ─── TOKEN TYPE ──────────────────────────────────────────────────────────────

    @Transactional
    public ClientResponse setRefreshable(String clientId, boolean refreshable) {
        OAuthClient client = requireClientInTenant(clientId);
        client.setRefreshable(refreshable);

        // Ensure refresh_token grant is present if refreshable
        if (refreshable && !client.getAuthorizedGrantTypes().contains("refresh_token")) {
            client.getAuthorizedGrantTypes().add("refresh_token");
        }
        if (!refreshable) {
            client.getAuthorizedGrantTypes().remove("refresh_token");
        }

        clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);

        log.info("Set refreshable={} for client '{}'", refreshable, clientId);
        eventPublisher.publishEvent(
            new ClientDomainEvent(this, ClientDomainEvent.EventType.TOKEN_TYPE_CHANGED, client));

        return clientMapper.toResponse(client);
    }

    // ─── TOKEN SETTINGS ──────────────────────────────────────────────────────────

    @Transactional
    public ClientResponse updateTokenSettings(String clientId,
                                               Long accessTokenValidity,
                                               Long refreshTokenValidity) {
        OAuthClient client = requireClientInTenant(clientId);

        if (accessTokenValidity != null)  client.setAccessTokenValidity(accessTokenValidity);
        if (refreshTokenValidity != null) client.setRefreshTokenValidity(refreshTokenValidity);

        clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);
        return clientMapper.toResponse(client);
    }

    // ─── STATUS ──────────────────────────────────────────────────────────────────

    @Transactional
    public ClientResponse suspendClient(String clientId) {
        OAuthClient client = requireClientInTenant(clientId);
        client.setStatus(OAuthClient.ClientStatus.SUSPENDED);
        clientRepository.save(client);
        tokenCacheService.evictAllForClient(clientId);
        log.info("Suspended client '{}'", clientId);
        return clientMapper.toResponse(client);
    }

    @Transactional
    public ClientResponse activateClient(String clientId) {
        OAuthClient client = requireClientInTenant(clientId);
        client.setStatus(OAuthClient.ClientStatus.ACTIVE);
        clientRepository.save(client);
        return clientMapper.toResponse(client);
    }

    // ─── HELPERS ─────────────────────────────────────────────────────────────────

    private OAuthClient requireClientInTenant(String clientId) {
        String tenantId = TenantContext.getCurrentTenant();
        return clientRepository.findByClientIdAndTenantId(clientId, tenantId)
            .orElseThrow(() -> new OAuthExceptions.ClientNotFoundException(clientId));
    }

    private String resolveTenant(String requested) {
        if (requested != null && !requested.isBlank()) return requested.trim().toLowerCase();
        return TenantContext.getCurrentTenant();
    }

    private void validateTenantExists(String tenantId) {
        if (!tenantRepository.existsByTenantCode(tenantId)) {
            throw new OAuthExceptions.TenantNotFoundException(tenantId);
        }
    }

    private String sanitize(String name) {
        return name.toLowerCase().replaceAll("[^a-z0-9]", "").substring(0, Math.min(name.length(), 10));
    }
}