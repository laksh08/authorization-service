package com.oauth.admin.controller;

import com.oauth.admin.dto.*;
import com.oauth.admin.service.AdminClientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/clients")
@RequiredArgsConstructor
@Tag(name = "Admin - Client Management", description = "CRUD and configuration for OAuth clients")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasAuthority('SCOPE_admin')")
public class AdminClientController {

    private final AdminClientService clientService;

    // ─── CREATE ──────────────────────────────────────────────────────────────────

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Create a new OAuth client",
               description = "Returns the client secret once — store it immediately.")
    public ResponseEntity<ClientCreatedResponse> createClient(
            @Valid @RequestBody CreateClientRequest request) {
        ClientCreatedResponse response = clientService.createClient(request);
        return ResponseEntity.status(HttpStatus.CREATED).body(response);
    }

    // ─── READ ────────────────────────────────────────────────────────────────────

    @GetMapping("/{clientId}")
    @Operation(summary = "Get client details by clientId")
    public ResponseEntity<ClientResponse> getClient(@PathVariable String clientId) {
        return ResponseEntity.ok(clientService.getClient(clientId));
    }

    @GetMapping
    @Operation(summary = "List all clients for current tenant")
    public ResponseEntity<List<ClientResponse>> listClients(
            @RequestParam(required = false) String tenantId) {
        return ResponseEntity.ok(clientService.getAllClientsForTenant(tenantId));
    }

    @GetMapping("/search")
    @Operation(summary = "Search clients by name")
    public ResponseEntity<Page<ClientResponse>> searchClients(
            @RequestParam String name,
            @PageableDefault(size = 20) Pageable pageable) {
        return ResponseEntity.ok(clientService.searchClients(name, pageable));
    }

    // ─── UPDATE ──────────────────────────────────────────────────────────────────

    @PutMapping("/{clientId}")
    @Operation(summary = "Update client info (scopes, grant types, validity, etc.)")
    public ResponseEntity<ClientResponse> updateClient(
            @PathVariable String clientId,
            @Valid @RequestBody UpdateClientRequest request) {
        return ResponseEntity.ok(clientService.updateClient(clientId, request));
    }

    @PatchMapping("/{clientId}/token-settings")
    @Operation(summary = "Update token validity settings")
    public ResponseEntity<ClientResponse> updateTokenSettings(
            @PathVariable String clientId,
            @RequestBody Map<String, Long> settings) {
        return ResponseEntity.ok(clientService.updateTokenSettings(
            clientId,
            settings.get("accessTokenValidity"),
            settings.get("refreshTokenValidity")
        ));
    }

    @PatchMapping("/{clientId}/refreshable")
    @Operation(summary = "Enable or disable refresh token support")
    public ResponseEntity<ClientResponse> setRefreshable(
            @PathVariable String clientId,
            @RequestParam boolean enabled) {
        return ResponseEntity.ok(clientService.setRefreshable(clientId, enabled));
    }

    // ─── DELETE ──────────────────────────────────────────────────────────────────

    @DeleteMapping("/{clientId}")
    @ResponseStatus(HttpStatus.NO_CONTENT)
    @Operation(summary = "Soft-delete an OAuth client")
    public ResponseEntity<Void> deleteClient(@PathVariable String clientId) {
        clientService.deleteClient(clientId);
        return ResponseEntity.noContent().build();
    }

    // ─── SECRET MANAGEMENT ───────────────────────────────────────────────────────

    @PostMapping("/{clientId}/secret/reset")
    @Operation(summary = "Reset the client secret — returns new secret once")
    public ResponseEntity<ClientCreatedResponse> resetSecret(@PathVariable String clientId) {
        return ResponseEntity.ok(clientService.resetClientSecret(clientId));
    }

    @PostMapping("/{clientId}/password/reset")
    @Operation(summary = "Set a specific password for the client (admin-driven)")
    public ResponseEntity<Map<String, String>> resetPassword(
            @PathVariable String clientId,
            @RequestBody Map<String, String> body) {
        String newPassword = body.get("password");
        String result = clientService.resetClientPassword(clientId, newPassword);
        return ResponseEntity.ok(Map.of("message", result));
    }

    @GetMapping("/generate-password")
    @Operation(summary = "Generate a random secure password for use as client secret")
    public ResponseEntity<Map<String, String>> generateRandomPassword() {
        return ResponseEntity.ok(Map.of("password", clientService.generateRandomPassword()));
    }

    // ─── STATUS ──────────────────────────────────────────────────────────────────

    @PostMapping("/{clientId}/suspend")
    @Operation(summary = "Suspend an OAuth client")
    public ResponseEntity<ClientResponse> suspendClient(@PathVariable String clientId) {
        return ResponseEntity.ok(clientService.suspendClient(clientId));
    }

    @PostMapping("/{clientId}/activate")
    @Operation(summary = "Activate a suspended OAuth client")
    public ResponseEntity<ClientResponse> activateClient(@PathVariable String clientId) {
        return ResponseEntity.ok(clientService.activateClient(clientId));
    }
}