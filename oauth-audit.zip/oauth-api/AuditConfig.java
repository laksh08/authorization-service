package com.cbsh.sba.oauth.audit.service;

import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.scheduling.annotation.EnableAsync;
import org.springframework.scheduling.concurrent.ThreadPoolTaskExecutor;

import java.util.concurrent.Executor;

/**
 * Configures a dedicated thread pool for async audit writes.
 * Isolated so that a burst of audit events cannot starve API request threads.
 */
@Configuration
@EnableAsync
public class AuditConfig {

    @Bean("auditExecutor")
    public Executor auditExecutor() {
        ThreadPoolTaskExecutor exec = new ThreadPoolTaskExecutor();
        exec.setCorePoolSize(2);
        exec.setMaxPoolSize(8);
        exec.setQueueCapacity(500);
        exec.setThreadNamePrefix("audit-");
        exec.setRejectedExecutionHandler((r, e) ->
            // On overflow: run inline rather than drop the audit record
            r.run()
        );
        exec.initialize();
        return exec;
    }
}