package com.cbsh.sba.oauth.audit.aspect;

import com.oauth.core.domain.AuditLog;

import java.lang.annotation.ElementType;
import java.lang.annotation.Retention;
import java.lang.annotation.RetentionPolicy;
import java.lang.annotation.Target;

/**
 * Place on any service method to have it automatically audit-logged.
 *
 * <pre>
 * {@literal @}Auditable(action = "CLIENT_CREATED")
 * public ClientResponse createClient(...) { ... }
 * </pre>
 *
 * The AOP aspect extracts clientId, tenantId, caller IP, and HTTP principal
 * automatically from the security context and request.
 */
@Target(ElementType.METHOD)
@Retention(RetentionPolicy.RUNTIME)
public @interface Auditable {

    /** Short action label stored in audit_logs.action */
    String action();

    /** Whether to capture the method arguments as request payload */
    boolean captureRequest() default true;

    /** Whether to capture the return value as response payload */
    boolean captureResponse() default false;
}