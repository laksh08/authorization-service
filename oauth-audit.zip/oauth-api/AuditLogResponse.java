package com.cbsh.sba.oauth.audit.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.oauth.core.domain.AuditLog;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.UUID;

@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class AuditLogResponse {

    private UUID id;
    private String action;
    private String clientId;
    private String tenantId;
    private String performedBy;
    private String ipAddress;
    private AuditLog.AuditStatus status;
    private String errorMessage;
    private Instant createdAt;

    /** Included only when the caller explicitly requests full payload */
    private String requestPayload;
    private String responsePayload;

    public static AuditLogResponse from(AuditLog log, boolean includePayload) {
        AuditLogResponseBuilder builder = AuditLogResponse.builder()
                .id(log.getId())
                .action(log.getAction())
                .clientId(log.getClientId())
                .tenantId(log.getTenantId())
                .performedBy(log.getPerformedBy())
                .ipAddress(log.getIpAddress())
                .status(log.getStatus())
                .errorMessage(log.getErrorMessage())
                .createdAt(log.getCreatedAt());

        if (includePayload) {
            builder.requestPayload(log.getRequestPayload())
                   .responsePayload(log.getResponsePayload());
        }

        return builder.build();
    }
}