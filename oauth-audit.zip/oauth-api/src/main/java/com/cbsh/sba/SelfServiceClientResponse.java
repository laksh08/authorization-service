package com.cbsh.sba.oauth.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import com.oauth.core.domain.OAuthClient;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.Set;

/**
 * Client info safe to return to the client itself via the self-service portal.
 * Intentionally omits the hashed secret and internal fields.
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class SelfServiceClientResponse {

    private String   clientId;
    private String   clientName;
    private String   tenantId;
    private String   description;
    private OAuthClient.ClientStatus status;
    private boolean  refreshable;
    private long     accessTokenValidity;
    private long     refreshTokenValidity;
    private Set<String> scopes;
    private Set<String> authorizedGrantTypes;
    private Set<String> redirectUris;
    private Instant  createdAt;
    private Instant  updatedAt;
}