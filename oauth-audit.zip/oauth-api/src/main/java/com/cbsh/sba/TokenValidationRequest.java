package com.cbsh.sba.oauth.api.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TokenValidationRequest {

    @NotBlank(message = "token must not be blank")
    private String token;
}