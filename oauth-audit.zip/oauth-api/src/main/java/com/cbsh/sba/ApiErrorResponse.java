package com.cbsh.sba.oauth.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.List;

/**
 * Uniform error response body for all API error conditions.
 * Follows RFC 6749 error response format where applicable.
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class ApiErrorResponse {

    /** RFC 6749 / RFC 7807 short error code, e.g. "invalid_token" */
    private String error;

    /** Human-readable description */
    private String errorDescription;

    /** HTTP status code (mirrored in body for client convenience) */
    private int    status;

    /** Request path that triggered the error */
    private String path;

    /** Time the error occurred */
    private Instant timestamp;

    /** Field-level validation errors, present only on 400 */
    private List<FieldError> fieldErrors;

    @Data
    @Builder
    public static class FieldError {
        private String field;
        private String message;
        private Object rejectedValue;
    }
}