package com.cbsh.sba.oauth.api.service;

import com.oauth.api.dto.SelfServiceClientResponse;
import com.oauth.api.dto.SelfServiceUpdateRequest;
import com.oauth.cache.service.TokenCacheService;
import com.oauth.core.domain.OAuthClient;
import com.oauth.core.event.ClientDomainEvent;
import com.oauth.core.exception.OAuthExceptions;
import com.oauth.core.service.PasswordGeneratorService;
import com.oauth.infra.repository.OAuthClientRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.ApplicationEventPublisher;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.HashSet;

/**
 * Self-service operations that a client can perform on its own registration.
 * Enforces that clients may only view/modify their own record,
 * identified by the "client_id" claim in the calling JWT.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class SelfServiceClientService {

    private final OAuthClientRepository   clientRepository;
    private final PasswordGeneratorService passwordGenerator;
    private final PasswordEncoder          passwordEncoder;
    private final TokenCacheService        tokenCacheService;
    private final ApplicationEventPublisher eventPublisher;

    // ─── Read Own Profile ────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public SelfServiceClientResponse getMyProfile(Jwt callerJwt) {
        OAuthClient client = requireOwnClient(callerJwt);
        return toResponse(client);
    }

    // ─── Update Own Metadata ─────────────────────────────────────────────────────

    @Transactional
    public SelfServiceClientResponse updateMyProfile(Jwt callerJwt, SelfServiceUpdateRequest request) {
        OAuthClient client = requireOwnClient(callerJwt);
        boolean changed = false;

        if (request.getClientName() != null && !request.getClientName().equals(client.getClientName())) {
            client.setClientName(request.getClientName());
            changed = true;
        }
        if (request.getDescription() != null) {
            client.setDescription(request.getDescription());
            changed = true;
        }
        if (request.getRedirectUris() != null) {
            client.setRedirectUris(new HashSet<>(request.getRedirectUris()));
            changed = true;
        }
        if (request.getPostLogoutRedirectUris() != null) {
            client.setPostLogoutRedirectUris(new HashSet<>(request.getPostLogoutRedirectUris()));
            changed = true;
        }

        if (changed) {
            clientRepository.save(client);
            tokenCacheService.evictAllForClient(client.getClientId());
            log.info("Self-service update by client '{}'", client.getClientId());
            eventPublisher.publishEvent(
                new ClientDomainEvent(this, ClientDomainEvent.EventType.CLIENT_UPDATED, client));
        }

        return toResponse(client);
    }

    // ─── Rotate Own Secret ───────────────────────────────────────────────────────

    /**
     * A client may rotate its own secret. Returns the new raw secret exactly once.
     * The response MUST be stored immediately — it is not recoverable.
     */
    @Transactional
    public String rotateMySecret(Jwt callerJwt) {
        OAuthClient client = requireOwnClient(callerJwt);

        String newRawSecret = passwordGenerator.generateClientSecret();
        client.setClientSecret(passwordEncoder.encode(newRawSecret));
        clientRepository.save(client);
        tokenCacheService.evictAllForClient(client.getClientId());

        log.info("Self-service secret rotation by client '{}'", client.getClientId());
        eventPublisher.publishEvent(
            new ClientDomainEvent(this, ClientDomainEvent.EventType.CLIENT_SECRET_RESET, client));

        return newRawSecret;
    }

    // ─── View Own Token Usage (summary) ─────────────────────────────────────────

    @Transactional(readOnly = true)
    public SelfServiceClientResponse getMyTokenSettings(Jwt callerJwt) {
        OAuthClient client = requireOwnClient(callerJwt);
        return toResponse(client);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────────

    /**
     * Resolves and validates that the JWT caller owns the resolved client.
     * Throws 403 if the client_id claim is missing or mismatched.
     */
    private OAuthClient requireOwnClient(Jwt jwt) {
        String clientId = jwt.getClaimAsString("client_id");
        if (clientId == null || clientId.isBlank()) {
            throw new OAuthExceptions.TenantMismatchException("unknown", "unknown");
        }

        return clientRepository.findByClientId(clientId)
                .filter(OAuthClient::isActive)
                .orElseThrow(() -> new OAuthExceptions.ClientNotFoundException(clientId));
    }

    private SelfServiceClientResponse toResponse(OAuthClient client) {
        return SelfServiceClientResponse.builder()
                .clientId(client.getClientId())
                .clientName(client.getClientName())
                .tenantId(client.getTenantId())
                .description(client.getDescription())
                .status(client.getStatus())
                .refreshable(client.isRefreshable())
                .accessTokenValidity(client.getAccessTokenValidity())
                .refreshTokenValidity(client.getRefreshTokenValidity())
                .scopes(client.getScopes())
                .authorizedGrantTypes(client.getAuthorizedGrantTypes())
                .redirectUris(client.getRedirectUris())
                .createdAt(client.getCreatedAt())
                .updatedAt(client.getUpdatedAt())
                .build();
    }
}