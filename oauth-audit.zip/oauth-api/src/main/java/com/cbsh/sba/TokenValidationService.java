package com.cbsh.sba.oauth.api.service;

import com.oauth.api.dto.TokenValidationResponse;
import com.oauth.cache.blacklist.TokenBlacklistService;
import com.oauth.cache.service.TokenCacheService;
import com.oauth.core.domain.OAuthClient;
import com.oauth.core.exception.OAuthExceptions;
import com.oauth.infra.repository.OAuthClientRepository;
import com.oauth.security.jwt.JwtTokenService;
import io.jsonwebtoken.Claims;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.security.oauth2.jwt.JwtDecoder;
import org.springframework.security.oauth2.jwt.JwtException;
import org.springframework.stereotype.Service;

import java.time.Instant;
import java.util.*;
import java.util.stream.Collectors;

/**
 * Core token operations:
 *   - validate   : fast path — cache hit or full JWT parse + blacklist check
 *   - introspect : RFC 7662 token introspection
 *   - revoke     : blacklist the token's JTI in L1 + L2
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class TokenValidationService {

    private final JwtTokenService          jwtTokenService;
    private final JwtDecoder               jwtDecoder;
    private final TokenBlacklistService    blacklistService;
    private final TokenCacheService        tokenCacheService;
    private final OAuthClientRepository    clientRepository;

    // ─── Validate ────────────────────────────────────────────────────────────────

    /**
     * Validates a raw JWT string.
     * Flow:
     *   1. Extract JTI, check blacklist (Ehcache → MySQL)
     *   2. Check token-info cache for a previous successful validation
     *   3. Full JWT parse + signature verification
     *   4. Business rule checks (client active, tenant match)
     *   5. Cache the result
     */
    public TokenValidationResponse validate(String rawToken) {

        // ── Step 1: fast blacklist check before any decoding ─────────────────
        String jti = jwtTokenService.extractJti(rawToken);
        if (jti != null && blacklistService.isBlacklisted(jti)) {
            log.debug("Token rejected — blacklisted JTI: {}", jti);
            return inactive("Token has been revoked");
        }

        // ── Step 2: cache hit ────────────────────────────────────────────────
        if (jti != null) {
            Optional<Map<String, Object>> cached = tokenCacheService.getCachedTokenInfo(jti);
            if (cached.isPresent()) {
                return buildResponseFromClaims(cached.get());
            }
        }

        // ── Step 3: full JWT parse ───────────────────────────────────────────
        Claims claims;
        try {
            claims = jwtTokenService.parseAndValidate(rawToken);
        } catch (OAuthExceptions.InvalidTokenException e) {
            return inactive(e.getMessage());
        }

        // ── Step 4: business rules ───────────────────────────────────────────
        String clientId = claims.get("client_id", String.class);
        if (clientId != null) {
            Optional<OAuthClient> clientOpt = clientRepository.findByClientId(clientId);
            if (clientOpt.isPresent() && !clientOpt.get().isActive()) {
                return inactive("Client is inactive or deleted");
            }
        }

        // ── Step 5: cache ────────────────────────────────────────────────────
        Map<String, Object> claimMap = claimsToMap(claims);
        if (jti != null) {
            tokenCacheService.cacheTokenInfo(jti, claimMap);
        }

        return buildResponseFromClaims(claimMap);
    }

    // ─── Introspect (RFC 7662) ───────────────────────────────────────────────────

    /**
     * RFC 7662 introspection. Similar to validate but uses Spring's JwtDecoder
     * to leverage the full Authorization Server key resolution.
     */
    public TokenValidationResponse introspect(String rawToken) {
        // Blacklist check first
        String jti = jwtTokenService.extractJti(rawToken);
        if (jti != null && blacklistService.isBlacklisted(jti)) {
            return inactive("Token has been revoked");
        }

        try {
            Jwt jwt = jwtDecoder.decode(rawToken);

            // Expired check
            if (jwt.getExpiresAt() != null && jwt.getExpiresAt().isBefore(Instant.now())) {
                return inactive("Token has expired");
            }

            String  clientId = jwt.getClaimAsString("client_id");
            String  tenantId = jwt.getClaimAsString("tenant_id");
            List<String> scopeList = parseScopeClaim(jwt);

            // Verify client still active
            if (clientId != null) {
                Optional<OAuthClient> client = clientRepository.findByClientId(clientId);
                if (client.isPresent() && !client.get().isActive()) {
                    return inactive("Client is inactive");
                }
            }

            return TokenValidationResponse.builder()
                    .active(true)
                    .jti(jwt.getId())
                    .sub(jwt.getSubject())
                    .iss(jwt.getIssuer() != null ? jwt.getIssuer().toString() : null)
                    .clientId(clientId)
                    .tenantId(tenantId)
                    .scope(String.join(" ", scopeList))
                    .scopes(new HashSet<>(scopeList))
                    .iat(jwt.getIssuedAt()  != null ? jwt.getIssuedAt().getEpochSecond()  : null)
                    .exp(jwt.getExpiresAt() != null ? jwt.getExpiresAt().getEpochSecond() : null)
                    .tokenType("Bearer")
                    .build();

        } catch (JwtException e) {
            log.debug("Introspection failed: {}", e.getMessage());
            return inactive("Invalid or malformed token");
        }
    }

    // ─── Revoke ──────────────────────────────────────────────────────────────────

    /**
     * Revokes a token by blacklisting its JTI.
     * Does not throw if the token is already expired or blacklisted.
     */
    public void revoke(String rawToken, String revokedBy, String reason) {
        String jti     = jwtTokenService.extractJti(rawToken);
        Instant expiry = jwtTokenService.extractExpiry(rawToken);

        if (jti == null) {
            log.warn("Cannot revoke token — JTI could not be extracted");
            return;
        }

        if (blacklistService.isBlacklisted(jti)) {
            log.debug("Token JTI '{}' is already blacklisted", jti);
            return;
        }

        // Extract client/tenant for blacklist record
        String clientId = null;
        String tenantId = null;
        try {
            Claims claims = jwtTokenService.parseAndValidate(rawToken);
            clientId = claims.get("client_id", String.class);
            tenantId = claims.get("tenant_id", String.class);
        } catch (Exception e) {
            // Token may be expired but still revocable
            log.debug("Could not fully parse token during revocation: {}", e.getMessage());
        }

        blacklistService.blacklist(jti, clientId, tenantId, expiry, revokedBy, reason);
        tokenCacheService.evictToken(jti);

        log.info("Token revoked: JTI='{}' by='{}' reason='{}'", jti, revokedBy, reason);
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────────

    private TokenValidationResponse inactive(String reason) {
        return TokenValidationResponse.builder()
                .active(false)
                .reason(reason)
                .build();
    }

    @SuppressWarnings("unchecked")
    private TokenValidationResponse buildResponseFromClaims(Map<String, Object> claims) {
        List<String> scopeList = new ArrayList<>();
        Object scopeVal = claims.get("scope");
        if (scopeVal instanceof String s) {
            scopeList = Arrays.asList(s.split("\\s+"));
        } else if (scopeVal instanceof List<?> l) {
            scopeList = l.stream().map(Object::toString).collect(Collectors.toList());
        }

        return TokenValidationResponse.builder()
                .active(true)
                .jti((String) claims.get("jti"))
                .sub((String) claims.get("sub"))
                .iss((String) claims.get("iss"))
                .clientId((String) claims.get("client_id"))
                .tenantId((String) claims.get("tenant_id"))
                .scope(String.join(" ", scopeList))
                .scopes(new HashSet<>(scopeList))
                .iat(toLong(claims.get("iat")))
                .exp(toLong(claims.get("exp")))
                .tokenType("Bearer")
                .build();
    }

    private Map<String, Object> claimsToMap(Claims claims) {
        Map<String, Object> map = new HashMap<>(claims);
        if (claims.getId()        != null) map.put("jti", claims.getId());
        if (claims.getSubject()   != null) map.put("sub", claims.getSubject());
        if (claims.getIssuer()    != null) map.put("iss", claims.getIssuer());
        if (claims.getIssuedAt()  != null) map.put("iat", claims.getIssuedAt().toInstant().getEpochSecond());
        if (claims.getExpiration()!= null) map.put("exp", claims.getExpiration().toInstant().getEpochSecond());
        return map;
    }

    private Long toLong(Object val) {
        if (val == null) return null;
        if (val instanceof Long l)    return l;
        if (val instanceof Integer i) return i.longValue();
        if (val instanceof Number n)  return n.longValue();
        return null;
    }

    @SuppressWarnings("unchecked")
    private List<String> parseScopeClaim(Jwt jwt) {
        Object scopeVal = jwt.getClaim("scope");
        if (scopeVal instanceof String s && !s.isBlank()) {
            return Arrays.asList(s.split("\\s+"));
        }
        if (scopeVal instanceof List) {
            return ((List<Object>) scopeVal).stream()
                    .map(Object::toString)
                    .collect(Collectors.toList());
        }
        // Spring Authorization Server puts scopes in "scp" or the standard scope claim
        List<String> scp = jwt.getClaimAsStringList("scp");
        return scp != null ? scp : Collections.emptyList();
    }
}