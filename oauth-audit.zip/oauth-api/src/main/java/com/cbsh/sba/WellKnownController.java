package com.cbsh.sba.oauth.api.controller;

import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RestController;

import java.util.List;
import java.util.Map;

/**
 * OIDC / OAuth 2.0 Authorization Server Metadata (RFC 8414 + OIDC Discovery).
 * Supplements Spring Authorization Server's built-in /.well-known/openid-configuration
 * with additional server information.
 */
@RestController
@RequiredArgsConstructor
@Tag(name = "Discovery", description = "OAuth 2.0 / OIDC server metadata")
public class WellKnownController {

    @Value("${oauth.issuer-uri:http://localhost:9000}")
    private String issuerUri;

    /**
     * RFC 8414 Authorization Server Metadata.
     * Spring Authorization Server also exposes this at /.well-known/oauth-authorization-server
     * but this endpoint provides a human-readable version for documentation.
     */
    @GetMapping("/.well-known/oauth-platform-info")
    @Operation(summary = "OAuth Platform server metadata and capabilities")
    public ResponseEntity<Map<String, Object>> serverMetadata() {
        return ResponseEntity.ok(Map.of(
            "issuer",                                issuerUri,
            "authorization_endpoint",                issuerUri + "/oauth2/authorize",
            "token_endpoint",                        issuerUri + "/oauth2/token",
            "token_introspection_endpoint",          issuerUri + "/oauth2/introspect",
            "token_revocation_endpoint",             issuerUri + "/oauth2/revoke",
            "jwks_uri",                              issuerUri + "/oauth2/jwks",
            "userinfo_endpoint",                     issuerUri + "/userinfo",
            "custom_token_validation_endpoint",      issuerUri + "/token/validate",
            "custom_token_check_endpoint",           issuerUri + "/token/check",
            "custom_token_introspect_endpoint",      issuerUri + "/token/introspect",
            "grant_types_supported",                 List.of(
                "authorization_code",
                "client_credentials",
                "refresh_token",
                "urn:ietf:params:oauth:grant-type:device_code"
            ),
            "response_types_supported",              List.of("code"),
            "token_endpoint_auth_methods_supported", List.of(
                "client_secret_basic",
                "client_secret_post"
            ),
            "scopes_supported",                      List.of("openid", "read", "write", "admin"),
            "claims_supported",                      List.of(
                "sub", "iss", "iat", "exp", "jti",
                "client_id", "tenant_id", "client_name", "scope"
            ),
            "multi_tenant_support",  true,
            "token_blacklisting",    true,
            "ldap_sync_support",     true
        ));
    }
}