package com.cbsh.sba.oauth.api.controller;

import com.oauth.api.dto.SelfServiceClientResponse;
import com.oauth.api.dto.SelfServiceUpdateRequest;
import com.oauth.api.service.SelfServiceClientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Self-service portal: a client can view and update its own registration,
 * rotate its secret, and inspect its token settings — without admin involvement.
 *
 * All endpoints are scoped to the authenticated client_id claim in the JWT.
 * A client cannot access or modify any other client's data.
 *
 * Base path: /api/self-service
 */
@Slf4j
@RestController
@RequestMapping("/api/self-service")
@RequiredArgsConstructor
@Tag(name = "Self-Service Portal", description = "Client self-service: profile, secret rotation, token settings")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("isAuthenticated()")
public class SelfServicePortalController {

    private final SelfServiceClientService selfService;

    // ─── Profile ─────────────────────────────────────────────────────────────────

    @GetMapping("/me")
    @Operation(
        summary     = "Get my client profile",
        description = "Returns the calling client's own registration details. " +
                      "Identified by the client_id claim in the Bearer token."
    )
    public ResponseEntity<SelfServiceClientResponse> getMyProfile(
            @AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(selfService.getMyProfile(jwt));
    }

    @PatchMapping("/me")
    @Operation(
        summary     = "Update my client profile",
        description = "Allows the client to update its own name, description, " +
                      "and redirect URIs. Scope and grant type changes require admin action."
    )
    public ResponseEntity<SelfServiceClientResponse> updateMyProfile(
            @AuthenticationPrincipal Jwt jwt,
            @Valid @RequestBody SelfServiceUpdateRequest request) {
        return ResponseEntity.ok(selfService.updateMyProfile(jwt, request));
    }

    // ─── Token Settings ───────────────────────────────────────────────────────────

    @GetMapping("/me/token-settings")
    @Operation(
        summary     = "View my token validity settings",
        description = "Returns the current access_token_validity, refresh_token_validity, " +
                      "and refresh configuration for the calling client."
    )
    public ResponseEntity<SelfServiceClientResponse> getMyTokenSettings(
            @AuthenticationPrincipal Jwt jwt) {
        return ResponseEntity.ok(selfService.getMyTokenSettings(jwt));
    }

    // ─── Secret Rotation ─────────────────────────────────────────────────────────

    @PostMapping("/me/secret/rotate")
    @Operation(
        summary     = "Rotate my client secret",
        description = "Generates a new secret, invalidates the current one, and returns " +
                      "the new raw secret exactly once. Cannot be retrieved after this call."
    )
    public ResponseEntity<Map<String, String>> rotateMySecret(
            @AuthenticationPrincipal Jwt jwt) {

        String newSecret = selfService.rotateMySecret(jwt);
        return ResponseEntity.ok(Map.of(
            "clientSecret", newSecret,
            "message",      "New secret generated. Store it securely — it cannot be retrieved again."
        ));
    }
}