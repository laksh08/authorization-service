package com.cbsh.sba.oauth.api.dto;

import com.fasterxml.jackson.annotation.JsonInclude;
import lombok.Builder;
import lombok.Data;

import java.time.Instant;
import java.util.Set;

/**
 * Returned for both /token/validate and /token/introspect endpoints.
 * When active=false most optional fields are omitted.
 */
@Data
@Builder
@JsonInclude(JsonInclude.Include.NON_NULL)
public class TokenValidationResponse {

    /** RFC 7662 — core field: is the token currently valid and active? */
    private boolean active;

    /** JWT ID claim */
    private String jti;

    /** client_id the token was issued to */
    private String clientId;

    /** tenant the client belongs to */
    private String tenantId;

    /** token subject */
    private String sub;

    /** token issuer */
    private String iss;

    /** space-separated scope string */
    private String scope;

    /** parsed set of scopes (non-RFC, for convenience) */
    private Set<String> scopes;

    /** issued-at epoch second */
    private Long iat;

    /** expiry epoch second */
    private Long exp;

    /** token type, e.g. "Bearer" */
    private String tokenType;

    /** human-readable message when active=false */
    private String reason;
}