package com.cbsh.sba.oauth.api.dto;

import jakarta.validation.constraints.Size;
import lombok.Data;

import java.util.Set;

/**
 * A client may only update non-sensitive fields about itself.
 * Scopes, grant types, and validity windows require admin action.
 */
@Data
public class SelfServiceUpdateRequest {

    @Size(min = 3, max = 200)
    private String clientName;

    @Size(max = 1000)
    private String description;

    /**
     * Redirect URIs the client may self-manage.
     * Scopes / grant types changes always require admin approval.
     */
    private Set<String> redirectUris;

    private Set<String> postLogoutRedirectUris;
}