package com.cbsh.sba.oauth.api.handler;

import io.swagger.v3.oas.annotations.OpenAPIDefinition;
import io.swagger.v3.oas.annotations.enums.SecuritySchemeType;
import io.swagger.v3.oas.annotations.info.Contact;
import io.swagger.v3.oas.annotations.info.Info;
import io.swagger.v3.oas.annotations.info.License;
import io.swagger.v3.oas.annotations.security.OAuthFlow;
import io.swagger.v3.oas.annotations.security.OAuthFlows;
import io.swagger.v3.oas.annotations.security.OAuthScope;
import io.swagger.v3.oas.annotations.security.SecurityScheme;
import io.swagger.v3.oas.annotations.servers.Server;
import org.springframework.context.annotation.Configuration;

@Configuration
@OpenAPIDefinition(
    info = @Info(
        title       = "OAuth Authorization Platform API",
        version     = "1.0.0",
        description = """
            Enterprise OAuth 2.0 Authorization Service.

            ## Authentication
            Use a Bearer token obtained from `/oauth2/token`.

            ## Token Endpoints
            - `POST /token/validate`   — validate any token
            - `GET  /token/check`      — header-based validity check
            - `POST /token/introspect` — RFC 7662 introspection
            - `POST /token/revoke`     — revoke / blacklist a token
            - `GET  /token/info`       — caller's own claims

            ## Admin Endpoints (require `admin` scope)
            - `/admin/clients/**`      — client CRUD & management
            - `/admin/tenants/**`      — multi-tenant provisioning
            - `/admin/ldap/**`         — LDAP sync trigger & health

            ## Self-Service Portal
            - `/api/self-service/me`   — view/update own registration
            """,
        contact = @Contact(name = "Platform Team", email = "platform@example.com"),
        license = @License(name = "Apache 2.0", url = "https://www.apache.org/licenses/LICENSE-2.0")
    ),
    servers = {
        @Server(url = "http://localhost:9000", description = "Local development"),
        @Server(url = "https://auth.example.com", description = "Production")
    }
)
@SecurityScheme(
    name        = "bearerAuth",
    type        = SecuritySchemeType.HTTP,
    scheme      = "bearer",
    bearerFormat = "JWT",
    description = "JWT Bearer token from /oauth2/token"
)
@SecurityScheme(
    name  = "oAuth2ClientCredentials",
    type  = SecuritySchemeType.OAUTH2,
    flows = @OAuthFlows(
        clientCredentials = @OAuthFlow(
            tokenUrl = "${oauth.issuer-uri:http://localhost:9000}/oauth2/token",
            scopes   = {
                @OAuthScope(name = "read",   description = "Read access"),
                @OAuthScope(name = "write",  description = "Write access"),
                @OAuthScope(name = "admin",  description = "Administrative access"),
                @OAuthScope(name = "openid", description = "OpenID Connect")
            }
        )
    )
)
public class OpenApiConfig {
    // All configuration is via annotations above
}