package com.cbsh.sba.oauth.api.handler;

import com.oauth.api.dto.ApiErrorResponse;
import com.oauth.core.exception.OAuthExceptions;
import jakarta.servlet.http.HttpServletRequest;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.AccessDeniedException;
import org.springframework.security.core.AuthenticationException;
import org.springframework.validation.FieldError;
import org.springframework.web.bind.MethodArgumentNotValidException;
import org.springframework.web.bind.MissingRequestHeaderException;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RestControllerAdvice;
import org.springframework.web.method.annotation.MethodArgumentTypeMismatchException;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Centralised exception → HTTP response mapping for the entire API surface.
 * Produces a consistent {@link ApiErrorResponse} JSON body for every error.
 */
@Slf4j
@RestControllerAdvice
public class GlobalExceptionHandler {

    // ─── Domain Exceptions ───────────────────────────────────────────────────────

    @ExceptionHandler(OAuthExceptions.ClientNotFoundException.class)
    public ResponseEntity<ApiErrorResponse> handleClientNotFound(
            OAuthExceptions.ClientNotFoundException ex, HttpServletRequest req) {
        return error(HttpStatus.NOT_FOUND, "client_not_found", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.ClientAlreadyExistsException.class)
    public ResponseEntity<ApiErrorResponse> handleClientAlreadyExists(
            OAuthExceptions.ClientAlreadyExistsException ex, HttpServletRequest req) {
        return error(HttpStatus.CONFLICT, "client_already_exists", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.InvalidTokenException.class)
    public ResponseEntity<ApiErrorResponse> handleInvalidToken(
            OAuthExceptions.InvalidTokenException ex, HttpServletRequest req) {
        return error(HttpStatus.BAD_REQUEST, "invalid_token", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.TokenRevokedException.class)
    public ResponseEntity<ApiErrorResponse> handleTokenRevoked(
            OAuthExceptions.TokenRevokedException ex, HttpServletRequest req) {
        return error(HttpStatus.UNAUTHORIZED, "token_revoked", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.TenantNotFoundException.class)
    public ResponseEntity<ApiErrorResponse> handleTenantNotFound(
            OAuthExceptions.TenantNotFoundException ex, HttpServletRequest req) {
        return error(HttpStatus.NOT_FOUND, "tenant_not_found", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.TenantMismatchException.class)
    public ResponseEntity<ApiErrorResponse> handleTenantMismatch(
            OAuthExceptions.TenantMismatchException ex, HttpServletRequest req) {
        return error(HttpStatus.FORBIDDEN, "tenant_mismatch", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.InvalidClientStateException.class)
    public ResponseEntity<ApiErrorResponse> handleInvalidClientState(
            OAuthExceptions.InvalidClientStateException ex, HttpServletRequest req) {
        return error(HttpStatus.BAD_REQUEST, "invalid_client_state", ex.getMessage(), req);
    }

    @ExceptionHandler(OAuthExceptions.LdapSyncException.class)
    public ResponseEntity<ApiErrorResponse> handleLdapSync(
            OAuthExceptions.LdapSyncException ex, HttpServletRequest req) {
        log.error("LDAP sync error: {}", ex.getMessage(), ex);
        return error(HttpStatus.SERVICE_UNAVAILABLE, "ldap_sync_error", ex.getMessage(), req);
    }

    // ─── Security Exceptions ─────────────────────────────────────────────────────

    @ExceptionHandler(AccessDeniedException.class)
    public ResponseEntity<ApiErrorResponse> handleAccessDenied(
            AccessDeniedException ex, HttpServletRequest req) {
        return error(HttpStatus.FORBIDDEN, "access_denied",
                "You do not have permission to perform this action", req);
    }

    @ExceptionHandler(AuthenticationException.class)
    public ResponseEntity<ApiErrorResponse> handleAuthentication(
            AuthenticationException ex, HttpServletRequest req) {
        return error(HttpStatus.UNAUTHORIZED, "unauthorized",
                "Authentication is required to access this resource", req);
    }

    // ─── Validation Exceptions ───────────────────────────────────────────────────

    @ExceptionHandler(MethodArgumentNotValidException.class)
    public ResponseEntity<ApiErrorResponse> handleValidation(
            MethodArgumentNotValidException ex, HttpServletRequest req) {

        List<ApiErrorResponse.FieldError> fieldErrors = ex.getBindingResult()
                .getFieldErrors()
                .stream()
                .map(fe -> ApiErrorResponse.FieldError.builder()
                        .field(fe.getField())
                        .message(fe.getDefaultMessage())
                        .rejectedValue(fe.getRejectedValue())
                        .build())
                .collect(Collectors.toList());

        ApiErrorResponse body = ApiErrorResponse.builder()
                .error("validation_failed")
                .errorDescription("Request validation failed — see fieldErrors for details")
                .status(HttpStatus.BAD_REQUEST.value())
                .path(req.getRequestURI())
                .timestamp(Instant.now())
                .fieldErrors(fieldErrors)
                .build();

        return ResponseEntity.badRequest().body(body);
    }

    @ExceptionHandler(MissingRequestHeaderException.class)
    public ResponseEntity<ApiErrorResponse> handleMissingHeader(
            MissingRequestHeaderException ex, HttpServletRequest req) {
        return error(HttpStatus.BAD_REQUEST, "missing_header",
                "Required header missing: " + ex.getHeaderName(), req);
    }

    @ExceptionHandler(MethodArgumentTypeMismatchException.class)
    public ResponseEntity<ApiErrorResponse> handleTypeMismatch(
            MethodArgumentTypeMismatchException ex, HttpServletRequest req) {
        return error(HttpStatus.BAD_REQUEST, "type_mismatch",
                "Invalid value for parameter '" + ex.getName() + "'", req);
    }

    // ─── Generic Fallback ────────────────────────────────────────────────────────

    @ExceptionHandler(IllegalArgumentException.class)
    public ResponseEntity<ApiErrorResponse> handleIllegalArgument(
            IllegalArgumentException ex, HttpServletRequest req) {
        return error(HttpStatus.BAD_REQUEST, "bad_request", ex.getMessage(), req);
    }

    @ExceptionHandler(Exception.class)
    public ResponseEntity<ApiErrorResponse> handleGeneric(
            Exception ex, HttpServletRequest req) {
        log.error("Unhandled exception at {}: {}", req.getRequestURI(), ex.getMessage(), ex);
        return error(HttpStatus.INTERNAL_SERVER_ERROR, "internal_error",
                "An unexpected error occurred. Please try again later.", req);
    }

    // ─── Helper ──────────────────────────────────────────────────────────────────

    private ResponseEntity<ApiErrorResponse> error(HttpStatus status, String code,
                                                    String description, HttpServletRequest req) {
        ApiErrorResponse body = ApiErrorResponse.builder()
                .error(code)
                .errorDescription(description)
                .status(status.value())
                .path(req.getRequestURI())
                .timestamp(Instant.now())
                .build();
        return ResponseEntity.status(status).body(body);
    }
}