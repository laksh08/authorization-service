package com.cbsh.sba.oauth.api.dto;

import jakarta.validation.constraints.NotBlank;
import lombok.Data;

@Data
public class TokenRevokeRequest {

    @NotBlank(message = "token must not be blank")
    private String token;

    /** Optional hint: "access_token" or "refresh_token" */
    private String tokenTypeHint;

    /** Optional human-readable reason for revocation (stored in audit log) */
    private String reason;
}