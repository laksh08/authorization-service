package com.cbsh.sba.oauth.api.service;

import com.oauth.core.domain.Tenant;
import com.oauth.core.exception.OAuthExceptions;
import com.oauth.infra.repository.OAuthClientRepository;
import com.oauth.infra.repository.TenantRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.Map;

@Slf4j
@Service
@RequiredArgsConstructor
public class TenantService {

    private final TenantRepository      tenantRepository;
    private final OAuthClientRepository clientRepository;

    @Transactional(readOnly = true)
    public Tenant getTenant(String tenantCode) {
        return tenantRepository.findByTenantCode(tenantCode)
                .orElseThrow(() -> new OAuthExceptions.TenantNotFoundException(tenantCode));
    }

    @Transactional(readOnly = true)
    public List<Tenant> getAllActiveTenants() {
        return tenantRepository.findAllByStatus(Tenant.TenantStatus.ACTIVE);
    }

    @Transactional
    public Tenant createTenant(String tenantCode, String tenantName, String issuerUrl, String contactEmail) {
        if (tenantRepository.existsByTenantCode(tenantCode)) {
            throw new IllegalArgumentException("Tenant already exists: " + tenantCode);
        }

        Tenant tenant = Tenant.builder()
                .tenantCode(tenantCode.toLowerCase())
                .tenantName(tenantName)
                .issuerUrl(issuerUrl)
                .contactEmail(contactEmail)
                .status(Tenant.TenantStatus.ACTIVE)
                .build();

        tenant = tenantRepository.save(tenant);
        log.info("Created tenant '{}'", tenantCode);
        return tenant;
    }

    @Transactional(readOnly = true)
    public Map<String, Object> getTenantStats(String tenantCode) {
        getTenant(tenantCode); // validate it exists
        long activeClients = clientRepository.countActiveClientsByTenant(tenantCode);
        return Map.of(
            "tenantCode",    tenantCode,
            "activeClients", activeClients
        );
    }

    @Transactional
    public Tenant suspendTenant(String tenantCode) {
        Tenant tenant = getTenant(tenantCode);
        tenant.setStatus(Tenant.TenantStatus.SUSPENDED);
        return tenantRepository.save(tenant);
    }

    @Transactional
    public Tenant activateTenant(String tenantCode) {
        Tenant tenant = getTenant(tenantCode);
        tenant.setStatus(Tenant.TenantStatus.ACTIVE);
        return tenantRepository.save(tenant);
    }
}