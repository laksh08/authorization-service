package com.cbsh.sba.oauth.api.controller;

import com.oauth.api.dto.TokenRevokeRequest;
import com.oauth.api.dto.TokenValidationRequest;
import com.oauth.api.dto.TokenValidationResponse;
import com.oauth.api.service.TokenValidationService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.media.Content;
import io.swagger.v3.oas.annotations.media.Schema;
import io.swagger.v3.oas.annotations.responses.ApiResponse;
import io.swagger.v3.oas.annotations.responses.ApiResponses;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.http.HttpHeaders;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.security.core.annotation.AuthenticationPrincipal;
import org.springframework.security.oauth2.jwt.Jwt;
import org.springframework.web.bind.annotation.*;

import java.util.Map;

/**
 * Token management endpoints:
 *
 *  POST /token/validate         — quick active/inactive check (body or header)
 *  POST /token/introspect       — RFC 7662 introspection with full claims
 *  POST /token/revoke           — blacklist a token by JTI
 *  GET  /token/info             — caller's own token claims
 *  GET  /token/check            — lightweight header-only validity ping
 */
@Slf4j
@RestController
@RequestMapping("/token")
@RequiredArgsConstructor
@Tag(name = "Token Management", description = "Token validation, introspection, and revocation")
public class TokenValidationController {

    private final TokenValidationService tokenValidationService;

    // ─── Validate (body) ─────────────────────────────────────────────────────────

    @PostMapping("/validate")
    @Operation(
        summary     = "Validate a token",
        description = "Returns active=true if the token is valid, not expired, not blacklisted, " +
                      "and issued to an active client."
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Validation result",
                     content = @Content(schema = @Schema(implementation = TokenValidationResponse.class))),
        @ApiResponse(responseCode = "400", description = "Missing or blank token in request body")
    })
    public ResponseEntity<TokenValidationResponse> validateToken(
            @Valid @RequestBody TokenValidationRequest request) {

        TokenValidationResponse result = tokenValidationService.validate(request.getToken());
        log.debug("Token validation: active={}", result.isActive());
        return ResponseEntity.ok(result);
    }

    // ─── Validate (Authorization header) ────────────────────────────────────────

    @GetMapping("/check")
    @Operation(
        summary     = "Quick token check via Authorization header",
        description = "Reads the Bearer token from the Authorization header and " +
                      "returns a lightweight active/inactive response. No body required."
    )
    public ResponseEntity<TokenValidationResponse> checkTokenFromHeader(
            @Parameter(hidden = true)
            @RequestHeader(value = HttpHeaders.AUTHORIZATION, required = false) String authHeader) {

        if (authHeader == null || !authHeader.startsWith("Bearer ")) {
            return ResponseEntity.badRequest()
                    .body(TokenValidationResponse.builder()
                            .active(false)
                            .reason("No Bearer token in Authorization header")
                            .build());
        }

        String rawToken = authHeader.substring(7);
        return ResponseEntity.ok(tokenValidationService.validate(rawToken));
    }

    // ─── Introspect (RFC 7662) ───────────────────────────────────────────────────

    @PostMapping("/introspect")
    @SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasAuthority('SCOPE_read') or hasAuthority('SCOPE_admin')")
    @Operation(
        summary     = "RFC 7662 token introspection",
        description = "Returns full claims for a valid token. Requires the caller to be " +
                      "authenticated with read or admin scope."
    )
    public ResponseEntity<TokenValidationResponse> introspectToken(
            @Valid @RequestBody TokenValidationRequest request) {

        TokenValidationResponse result = tokenValidationService.introspect(request.getToken());
        return ResponseEntity.ok(result);
    }

    // ─── Revoke ──────────────────────────────────────────────────────────────────

    @PostMapping("/revoke")
    @SecurityRequirement(name = "bearerAuth")
    @PreAuthorize("hasAuthority('SCOPE_write') or hasAuthority('SCOPE_admin')")
    @Operation(
        summary     = "Revoke a token",
        description = "Adds the token's JTI to the blacklist (Ehcache L1 + MySQL L2). " +
                      "All subsequent requests carrying this token will be rejected with 401."
    )
    @ApiResponses({
        @ApiResponse(responseCode = "200", description = "Token revoked successfully"),
        @ApiResponse(responseCode = "400", description = "Missing or blank token")
    })
    public ResponseEntity<Map<String, String>> revokeToken(
            @Valid @RequestBody TokenRevokeRequest request,
            @AuthenticationPrincipal Jwt callerJwt) {

        String revokedBy = callerJwt != null ? callerJwt.getSubject() : "unknown";
        tokenValidationService.revoke(request.getToken(), revokedBy, request.getReason());

        return ResponseEntity.ok(Map.of(
            "status",  "revoked",
            "message", "Token has been successfully revoked"
        ));
    }

    // ─── Caller's Own Token Info ──────────────────────────────────────────────────

    @GetMapping("/info")
    @SecurityRequirement(name = "bearerAuth")
    @Operation(
        summary     = "Get calling token's claims",
        description = "Returns the parsed claims of the token making this request. " +
                      "Useful for the self-service portal and debugging."
    )
    public ResponseEntity<TokenValidationResponse> getTokenInfo(
            @AuthenticationPrincipal Jwt callerJwt) {

        if (callerJwt == null) {
            return ResponseEntity.ok(TokenValidationResponse.builder()
                    .active(false)
                    .reason("No authenticated token found")
                    .build());
        }

        // Build from already-decoded Spring JWT — no re-validation needed
        return ResponseEntity.ok(TokenValidationResponse.builder()
                .active(true)
                .jti(callerJwt.getId())
                .sub(callerJwt.getSubject())
                .iss(callerJwt.getIssuer() != null ? callerJwt.getIssuer().toString() : null)
                .clientId(callerJwt.getClaimAsString("client_id"))
                .tenantId(callerJwt.getClaimAsString("tenant_id"))
                .iat(callerJwt.getIssuedAt()  != null ? callerJwt.getIssuedAt().getEpochSecond()  : null)
                .exp(callerJwt.getExpiresAt() != null ? callerJwt.getExpiresAt().getEpochSecond() : null)
                .tokenType("Bearer")
                .build());
    }
}