package com.cbsh.sba.oauth.api.controller;

import com.oauth.api.dto.SelfServiceClientResponse;
import com.oauth.core.domain.OAuthClient;
import com.oauth.core.exception.OAuthExceptions;
import com.oauth.core.tenant.TenantContext;
import com.oauth.infra.repository.OAuthClientRepository;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

/**
 * Public-ish client-info endpoints.
 * GET /api/clients/{clientId}  — requires read or admin scope
 */
@RestController
@RequestMapping("/api/clients")
@RequiredArgsConstructor
@Tag(name = "Client Info", description = "Look up client details")
@SecurityRequirement(name = "bearerAuth")
public class ClientInfoController {

    private final OAuthClientRepository clientRepository;

    @GetMapping("/{clientId}")
    @PreAuthorize("hasAuthority('SCOPE_read') or hasAuthority('SCOPE_admin')")
    @Operation(
        summary     = "Get client details by clientId",
        description = "Returns client metadata for the given clientId within the current tenant. " +
                      "Does not expose the client secret."
    )
    public ResponseEntity<SelfServiceClientResponse> getClientDetails(
            @Parameter(description = "OAuth2 client_id") @PathVariable String clientId) {

        String tenantId = TenantContext.getCurrentTenant();

        OAuthClient client = clientRepository
                .findByClientIdAndTenantId(clientId, tenantId)
                .filter(OAuthClient::isActive)
                .orElseThrow(() -> new OAuthExceptions.ClientNotFoundException(clientId));

        return ResponseEntity.ok(SelfServiceClientResponse.builder()
                .clientId(client.getClientId())
                .clientName(client.getClientName())
                .tenantId(client.getTenantId())
                .description(client.getDescription())
                .status(client.getStatus())
                .refreshable(client.isRefreshable())
                .accessTokenValidity(client.getAccessTokenValidity())
                .refreshTokenValidity(client.getRefreshTokenValidity())
                .scopes(client.getScopes())
                .authorizedGrantTypes(client.getAuthorizedGrantTypes())
                .redirectUris(client.getRedirectUris())
                .createdAt(client.getCreatedAt())
                .updatedAt(client.getUpdatedAt())
                .build());
    }
}