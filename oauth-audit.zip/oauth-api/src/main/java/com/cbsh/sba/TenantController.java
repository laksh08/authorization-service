package com.cbsh.sba.oauth.api.controller;

import com.oauth.api.service.TenantService;
import com.oauth.core.domain.Tenant;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.constraints.NotBlank;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.util.List;
import java.util.Map;

@RestController
@RequestMapping("/admin/tenants")
@RequiredArgsConstructor
@Tag(name = "Admin - Tenant Management", description = "Multi-tenant provisioning and lifecycle")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasAuthority('SCOPE_admin')")
public class TenantController {

    private final TenantService tenantService;

    @PostMapping
    @ResponseStatus(HttpStatus.CREATED)
    @Operation(summary = "Create a new tenant")
    public ResponseEntity<Tenant> createTenant(@RequestBody Map<String, String> body) {
        Tenant tenant = tenantService.createTenant(
            body.get("tenantCode"),
            body.get("tenantName"),
            body.get("issuerUrl"),
            body.get("contactEmail")
        );
        return ResponseEntity.status(HttpStatus.CREATED).body(tenant);
    }

    @GetMapping
    @Operation(summary = "List all active tenants")
    public ResponseEntity<List<Tenant>> listTenants() {
        return ResponseEntity.ok(tenantService.getAllActiveTenants());
    }

    @GetMapping("/{tenantCode}")
    @Operation(summary = "Get tenant details")
    public ResponseEntity<Tenant> getTenant(@PathVariable @NotBlank String tenantCode) {
        return ResponseEntity.ok(tenantService.getTenant(tenantCode));
    }

    @GetMapping("/{tenantCode}/stats")
    @Operation(summary = "Get tenant statistics (client count, etc.)")
    public ResponseEntity<Map<String, Object>> getTenantStats(@PathVariable String tenantCode) {
        return ResponseEntity.ok(tenantService.getTenantStats(tenantCode));
    }

    @PostMapping("/{tenantCode}/suspend")
    @Operation(summary = "Suspend a tenant")
    public ResponseEntity<Tenant> suspendTenant(@PathVariable String tenantCode) {
        return ResponseEntity.ok(tenantService.suspendTenant(tenantCode));
    }

    @PostMapping("/{tenantCode}/activate")
    @Operation(summary = "Re-activate a suspended tenant")
    public ResponseEntity<Tenant> activateTenant(@PathVariable String tenantCode) {
        return ResponseEntity.ok(tenantService.activateTenant(tenantCode));
    }
}