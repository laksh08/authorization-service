package com.cbsh.sba.oauth.audit.controller;

import com.oauth.audit.dto.AuditLogResponse;
import com.oauth.audit.service.AuditService;
import com.oauth.core.domain.AuditLog;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.Parameter;
import io.swagger.v3.oas.annotations.security.SecurityRequirement;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.data.web.PageableDefault;
import org.springframework.format.annotation.DateTimeFormat;
import org.springframework.http.ResponseEntity;
import org.springframework.security.access.prepost.PreAuthorize;
import org.springframework.web.bind.annotation.*;

import java.time.Instant;
import java.util.List;
import java.util.stream.Collectors;

/**
 * Audit log query endpoints.
 * Requires admin scope — audit data is sensitive.
 *
 * GET /admin/audit/clients/{clientId}     — all logs for a client
 * GET /admin/audit/tenants/{tenantId}     — all logs for a tenant
 * GET /admin/audit/tenants/{id}/failures  — failure records only
 * GET /admin/audit/range                  — logs within a time window
 */
@RestController
@RequestMapping("/admin/audit")
@RequiredArgsConstructor
@Tag(name = "Admin - Audit Logs", description = "Query audit trail for clients and tenants")
@SecurityRequirement(name = "bearerAuth")
@PreAuthorize("hasAuthority('SCOPE_admin')")
public class AuditController {

    private final AuditService auditService;

    @GetMapping("/clients/{clientId}")
    @Operation(summary = "Get audit logs for a specific client")
    public ResponseEntity<Page<AuditLogResponse>> getClientAuditLogs(
            @PathVariable String clientId,
            @RequestParam(defaultValue = "false") boolean includePayload,
            @PageableDefault(size = 50, sort = "createdAt") Pageable pageable) {

        return ResponseEntity.ok(
            auditService.getLogsForClient(clientId, pageable)
                        .map(log -> AuditLogResponse.from(log, includePayload))
        );
    }

    @GetMapping("/tenants/{tenantId}")
    @Operation(summary = "Get audit logs for an entire tenant")
    public ResponseEntity<Page<AuditLogResponse>> getTenantAuditLogs(
            @PathVariable String tenantId,
            @RequestParam(defaultValue = "false") boolean includePayload,
            @PageableDefault(size = 50, sort = "createdAt") Pageable pageable) {

        return ResponseEntity.ok(
            auditService.getLogsForTenant(tenantId, pageable)
                        .map(log -> AuditLogResponse.from(log, includePayload))
        );
    }

    @GetMapping("/tenants/{tenantId}/failures")
    @Operation(summary = "Get only FAILURE audit records for a tenant")
    public ResponseEntity<List<AuditLogResponse>> getTenantFailures(
            @PathVariable String tenantId,
            @RequestParam(defaultValue = "false") boolean includePayload,
            @PageableDefault(size = 100) Pageable pageable) {

        List<AuditLogResponse> failures = auditService
                .getFailuresForTenant(tenantId, pageable)
                .stream()
                .map(log -> AuditLogResponse.from(log, includePayload))
                .collect(Collectors.toList());

        return ResponseEntity.ok(failures);
    }

    @GetMapping("/range")
    @Operation(
        summary     = "Get audit logs within a time range",
        description = "Both `from` and `to` are ISO-8601 instants, e.g. 2024-01-01T00:00:00Z"
    )
    public ResponseEntity<List<AuditLogResponse>> getLogsByRange(
            @Parameter(description = "Start of range (ISO-8601)")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant from,

            @Parameter(description = "End of range (ISO-8601)")
            @RequestParam @DateTimeFormat(iso = DateTimeFormat.ISO.DATE_TIME) Instant to,

            @RequestParam(defaultValue = "false") boolean includePayload) {

        List<AuditLogResponse> logs = auditService.getLogsByDateRange(from, to)
                .stream()
                .map(log -> AuditLogResponse.from(log, includePayload))
                .collect(Collectors.toList());

        return ResponseEntity.ok(logs);
    }
}