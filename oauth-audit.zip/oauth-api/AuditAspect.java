package com.cbsh.sba.oauth.audit.aspect;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.oauth.audit.service.AuditService;
import com.oauth.core.domain.AuditLog;
import com.oauth.core.tenant.TenantContext;
import jakarta.servlet.http.HttpServletRequest;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.aspectj.lang.ProceedingJoinPoint;
import org.aspectj.lang.annotation.Around;
import org.aspectj.lang.annotation.Aspect;
import org.aspectj.lang.reflect.MethodSignature;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.context.SecurityContextHolder;
import org.springframework.stereotype.Component;
import org.springframework.web.context.request.RequestContextHolder;
import org.springframework.web.context.request.ServletRequestAttributes;

import java.lang.reflect.Method;

/**
 * Intercepts all methods annotated with {@link Auditable} and persists
 * an {@link AuditLog} record asynchronously via {@link AuditService}.
 *
 * Captures:
 *   - action label from the annotation
 *   - clientId / tenantId from the TenantContext or method arguments
 *   - caller principal name from the Spring SecurityContext
 *   - client IP from the HTTP request (if available)
 *   - request args (JSON) when captureRequest = true
 *   - return value (JSON) when captureResponse = true
 *   - error message on exception
 */
@Slf4j
@Aspect
@Component
@RequiredArgsConstructor
public class AuditAspect {

    private final AuditService  auditService;
    private final ObjectMapper  objectMapper;

    @Around("@annotation(com.oauth.audit.aspect.Auditable)")
    public Object auditMethod(ProceedingJoinPoint pjp) throws Throwable {

        MethodSignature sig    = (MethodSignature) pjp.getSignature();
        Method          method = sig.getMethod();
        Auditable       ann    = method.getAnnotation(Auditable.class);

        String action     = ann.action();
        String tenantId   = TenantContext.getCurrentTenant();
        String principal  = resolvePrincipal();
        String ip         = resolveClientIp();
        String clientId   = extractClientIdArg(pjp.getArgs(), sig.getParameterNames());
        String requestJson = ann.captureRequest()  ? toJson(pjp.getArgs()) : null;

        try {
            Object result    = pjp.proceed();
            String respJson  = ann.captureResponse() ? toJson(result) : null;

            auditService.record(AuditLog.builder()
                    .action(action)
                    .clientId(clientId)
                    .tenantId(tenantId)
                    .performedBy(principal)
                    .ipAddress(ip)
                    .requestPayload(requestJson)
                    .responsePayload(respJson)
                    .status(AuditLog.AuditStatus.SUCCESS)
                    .build());

            return result;

        } catch (Exception ex) {
            auditService.record(AuditLog.builder()
                    .action(action)
                    .clientId(clientId)
                    .tenantId(tenantId)
                    .performedBy(principal)
                    .ipAddress(ip)
                    .requestPayload(requestJson)
                    .status(AuditLog.AuditStatus.FAILURE)
                    .errorMessage(ex.getClass().getSimpleName() + ": " + truncate(ex.getMessage(), 490))
                    .build());

            throw ex;
        }
    }

    // ─── Helpers ─────────────────────────────────────────────────────────────────

    private String resolvePrincipal() {
        try {
            Authentication auth = SecurityContextHolder.getContext().getAuthentication();
            return (auth != null && auth.isAuthenticated()) ? auth.getName() : "anonymous";
        } catch (Exception e) {
            return "unknown";
        }
    }

    private String resolveClientIp() {
        try {
            ServletRequestAttributes attrs =
                (ServletRequestAttributes) RequestContextHolder.getRequestAttributes();
            if (attrs == null) return null;

            HttpServletRequest req = attrs.getRequest();
            String xff = req.getHeader("X-Forwarded-For");
            if (xff != null && !xff.isBlank()) return xff.split(",")[0].trim();
            return req.getRemoteAddr();
        } catch (Exception e) {
            return null;
        }
    }

    /**
     * Looks for a method parameter named "clientId" or whose value starts with
     * a typical client-id prefix to capture in the audit record.
     */
    private String extractClientIdArg(Object[] args, String[] paramNames) {
        if (args == null || paramNames == null) return null;
        for (int i = 0; i < paramNames.length; i++) {
            if ("clientId".equalsIgnoreCase(paramNames[i]) && args[i] != null) {
                return args[i].toString();
            }
        }
        return null;
    }

    private String toJson(Object obj) {
        if (obj == null) return null;
        try {
            return truncate(objectMapper.writeValueAsString(obj), 3900);
        } catch (Exception e) {
            return obj.toString();
        }
    }

    private String truncate(String s, int maxLen) {
        if (s == null) return null;
        return s.length() > maxLen ? s.substring(0, maxLen) + "…" : s;
    }
}