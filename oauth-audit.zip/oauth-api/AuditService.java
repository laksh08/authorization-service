package com.cbsh.sba.oauth.audit.service;

import com.oauth.core.domain.AuditLog;
import com.oauth.core.event.ClientDomainEvent;
import com.oauth.infra.repository.AuditLogRepository;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.context.event.EventListener;
import org.springframework.data.domain.Page;
import org.springframework.data.domain.Pageable;
import org.springframework.scheduling.annotation.Async;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Propagation;
import org.springframework.transaction.annotation.Transactional;

import java.time.Instant;
import java.util.List;

/**
 * Persists audit records.
 *
 * All writes are async (fire-and-forget) so that audit logging never blocks
 * the calling thread or inflates API response latency.
 *
 * Also listens for {@link ClientDomainEvent} published by admin/ldap/api
 * modules and converts them to audit log entries automatically.
 */
@Slf4j
@Service
@RequiredArgsConstructor
public class AuditService {

    private final AuditLogRepository auditLogRepository;

    // ─── Write (Async) ───────────────────────────────────────────────────────────

    /**
     * Persists an audit record on a separate thread.
     * Uses REQUIRES_NEW so a failure here never rolls back the business transaction.
     */
    @Async("auditExecutor")
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void record(AuditLog log) {
        try {
            auditLogRepository.save(log);
        } catch (Exception e) {
            // Audit failures must never propagate — log and swallow
            this.log.error("Failed to persist audit log [action={}]: {}", log.getAction(), e.getMessage());
        }
    }

    /**
     * Synchronous variant — used by tests or when the caller must wait.
     */
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void recordSync(AuditLog auditLog) {
        try {
            auditLogRepository.save(auditLog);
        } catch (Exception e) {
            log.error("Failed to persist audit log [action={}]: {}", auditLog.getAction(), e.getMessage());
        }
    }

    // ─── Domain Event → Audit ────────────────────────────────────────────────────

    /**
     * Listens for {@link ClientDomainEvent} from any module and writes
     * a corresponding audit record without those modules depending on oauth-audit.
     */
    @Async("auditExecutor")
    @EventListener
    @Transactional(propagation = Propagation.REQUIRES_NEW)
    public void onClientDomainEvent(ClientDomainEvent event) {
        record(AuditLog.builder()
                .action(event.getEventType().name())
                .clientId(event.getClientId())
                .tenantId(event.getTenantId())
                .performedBy("system-event")
                .status(AuditLog.AuditStatus.SUCCESS)
                .build());
    }

    // ─── Query ───────────────────────────────────────────────────────────────────

    @Transactional(readOnly = true)
    public Page<AuditLog> getLogsForClient(String clientId, Pageable pageable) {
        return auditLogRepository.findByClientIdOrderByCreatedAtDesc(clientId, pageable);
    }

    @Transactional(readOnly = true)
    public Page<AuditLog> getLogsForTenant(String tenantId, Pageable pageable) {
        return auditLogRepository.findByTenantIdOrderByCreatedAtDesc(tenantId, pageable);
    }

    @Transactional(readOnly = true)
    public List<AuditLog> getLogsByDateRange(Instant from, Instant to) {
        return auditLogRepository.findByDateRange(from, to);
    }

    @Transactional(readOnly = true)
    public List<AuditLog> getFailuresForTenant(String tenantId, Pageable pageable) {
        return auditLogRepository.findFailuresByTenant(tenantId, pageable);
    }
}